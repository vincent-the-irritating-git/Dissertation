package dissertation_server;

import server_side.Message;

import java.io.*;
import java.net.Socket;

/**
 * Client Thread Handler class
 */
public class ClientHandler implements Runnable {
  private Socket   clientSocket;

  /**
   * constructor
   */
  public ClientHandler(Socket client
                       ) throws IOException, ClassNotFoundException {
    this.clientSocket = client;
  }

  public ClientHandler(){}

  @Override
  public void run() {
    Protocol p=new Protocol();
    try {
      /**
       * this is the input stream to take in the data message we get from the
       * client. it's cast as a jabbermessage
       */
      ObjectInputStream in =
          new ObjectInputStream(clientSocket.getInputStream());
      /**
       * can't put the readObject here, because it blocks
       */

      /**
       * now we need an object output stream to send things to the server
       */
      ObjectOutputStream out =
          new ObjectOutputStream(clientSocket.getOutputStream());

      /**
       * now read the client's message in
       */

      while (true) {
        Message message = ((Message) in.readObject());
        System.out.println("message in from client is " +
                           "\"" +
                           message.getMessage() +
                           "\"");
        /**
         * so here we pass the message and see which method to call
         * based on the message received
         */
        p.protocolToUse(message);
        out.writeObject(p.getM());
        out.flush();
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}