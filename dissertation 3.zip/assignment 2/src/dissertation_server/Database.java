package dissertation_server;

import org.postgresql.util.PSQLException;

import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Database {

  private static String dbcommand =
      "jdbc:postgresql://localhost:5432/PlantDiet";
  private static String db        = "postgres";
  private static String pw        = "asda";

  private Connection conn;

  /**
   * Returns the current database connection.
   *
   * @return the database connection.
   */
  public Connection getConnection() {
    return conn;
  }

  /**
   * Default constructor. Connects to the database.
   */
  public Database() {
    connectToDatabase();
    //resetDatabase();
  }

  public void connectToDatabase() {

    try {
      conn = DriverManager.getConnection(dbcommand, db, pw);

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  //takes email and password
  //if they match, return the userid to the client
  //and let them know they can sign in
  public Boolean signIn(String email, String password) {
    String query = "SELECT userid FROM person WHERE email=? AND " +
                   "password=?";
    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.setString(1, email);
      ps.setString(2, password);
      ResultSet rs = ps.executeQuery();
      while (rs.next()) {
        if (!rs.isBeforeFirst()) {
          return true;
        }
      }
    } catch (SQLException throwables) {
      throwables.printStackTrace();
    }
    return false;
  }

  //attempts to add user, does if successful
  public Boolean isAddedUser(String email, String username, String password,
  String age, String height) {
    String query =
        "INSERT INTO PERSON(email, name, password, age, height) VALUES (?,?,?,?,?)";

    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.setString(1, email);
      ps.setString(2, username);
      ps.setString(3, password);
      ps.setInt(4, Integer.parseInt(age));
      ps.setInt(5, Integer.parseInt(height));

      int i = ps.executeUpdate();
      return i > 0;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return false;
  }

  public int getIDNumber(String email){
    String query="SELECT userid FROM person WHERE email=?";
    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.setString(1,email);
      ResultSet rs=ps.executeQuery();
      while (rs.next()){
        return Integer.parseInt(rs.getObject("userid").toString());
      }
    }catch(Exception e){e.printStackTrace();}
    return 255;
  }

  public boolean addWeight(int userid, String weight){
    String query ="INSERT INTO weight (person,weight) VALUES(?,?)";
    try{
      PreparedStatement ps=conn.prepareStatement(query);
      ps.setInt(1, userid);
      ps.setInt(2, Integer.parseInt(weight));
      int i = ps.executeUpdate();
      return i > 0;
      } catch (Exception e) {
      e.printStackTrace();
  }
    return false;
  }

  public int getCalories(int userid) {
    String query = "SELECT calorie_goal FROM person WHERE userid=?";

    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.setInt(1, userid);
      ResultSet rs = ps.executeQuery();
      while (rs.next()) {
        return (int) rs.getObject("calorie_goal");
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return 0;
  }

  public ArrayList<ArrayList<String>> getMealList(String email) {
    String query = "SELECT DISTINCT dishid,dish.name,isVegan," +
                   "preset_calories\n" +
                   "FROM dish\n" +
                   "INNER JOIN calories ON dish.dishID=calories.dish \n" +
                   "INNER JOIN itemdish ON itemdish.dish=calories.dish\n" +
                   "INNER JOIN item ON item.itemID=itemdish.item\n" +
                   "WHERE person=? ORDER BY dishid";
    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.setInt(1, getIDNumber(email));
      ResultSet rs = ps.executeQuery();
      ArrayList<String>name=new ArrayList<>();
      ArrayList<String>isVegan=new ArrayList<>();
      ArrayList<String>preset_calories=new ArrayList<>();
      ArrayList<ArrayList<String>>temp2=new ArrayList<>();
      if(rs.isBeforeFirst()) {
        while (rs.next()) {
          name.add(rs.getObject("name").toString());
          isVegan.add(rs.getObject("isVegan").toString());
          preset_calories.add(rs.getObject("preset_calories").toString());
        }

        for (int x=0; x<name.size();++x){
          ArrayList<String>dish=new ArrayList<>();
          dish.add(name.get(x));
          dish.add(isVegan.get(x));
          dish.add(preset_calories.get(x));
          temp2.add(dish);
        }
        return temp2;
      }
      else{
        ArrayList<ArrayList<String>>blank=new ArrayList<>();
        return blank;
      }
    } catch (SQLException throwables) {
      throwables.printStackTrace();
    }
    return null;
  }

    public void dropTables() {

    String[] commands = {
        "drop table person cascade;",
        "drop table item cascade;",
        "drop table dish cascade;",
        "drop table itemdish cascade;",
        "drop table calories cascade;",
        "drop table weight cascade;"};

    for (String query : commands) {

      try (PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.executeUpdate();
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
  }

  public void resetDatabase(String file, String file2) {

    dropTables();

    ArrayList<String> defs = loadSQL(file);

    ArrayList<String> data =  loadSQL(file2);

    executeSQLUpdates(defs);
    executeSQLUpdates(data);
  }

  private void executeSQLUpdates(ArrayList<String> commands) {

    for (String query: commands) {

      try (PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.executeUpdate();
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
  }

  private ArrayList<String> loadSQL(String sqlfile) {

    /*
     * This method is to be used only by the resetDatabase() code.
     * Do not use it yourself to load your own SQL.
     */

    ArrayList<String> commands = new ArrayList<String>();

    try {
      BufferedReader reader = new BufferedReader(new FileReader(sqlfile + ".sql"));

      String command = "";

      String line = "";

      while ((line = reader.readLine())!= null) {

        if (line.contains(";")) {
          command += line;
          command = command.trim();
          commands.add(command);
          command = "";
        }

        else {
          line = line.trim();
          command += line + " ";
        }
      }

      reader.close();

    } catch (IOException e) {
      e.printStackTrace();
    }

    return commands;

  }
}
