package dissertation_server;

import server_side.Message;

import java.util.ArrayList;

public class Protocol {

  private String                       debug = "signin Will";
  private Message                      m;
  private String                       messageBody;
  private ArrayList<ArrayList<String>> data;
  private Database                     db    = new Database();

  public Message getM() {
    return m;
  }

  public void protocolToUse(Message message) {
    String[] protocol;
    protocol = message.getMessage().split(" ", 7);
    switch (protocol[0]) {
      default:
        m = new Message("invalid-response");
        return;
      case "signin":
        try {
          signin(protocol[1], protocol[2]);
        } catch (ArrayIndexOutOfBoundsException e) {
          e.printStackTrace();
        }
        return;
      case "register":
        try {
          register(protocol[1], protocol[2], protocol[3], protocol[4],
                   protocol[5], protocol[6]);
        } catch (ArrayIndexOutOfBoundsException | NumberFormatException e) {
          e.printStackTrace();
        }
        return;
      case "get-calories":
        getCalories(protocol[1]);
        return;
      case "meals":
        getMealList(protocol[1]);
        return;
    }
  }

  public Message getCalories(String email) {
    messageBody = String.valueOf(db.getCalories(db.getIDNumber(email)));
    return m = new Message(messageBody);
  }

  public Message signin(String email, String password) {
    if (db.signIn(email, password)) {
      db.getIDNumber(email);
      messageBody = "signed-in";
    } else {
      messageBody = "unknown-user";
    }
    return m = new Message(messageBody);
  }

  public Message register(String email, String username, String password,
                          String age, String height, String weight) {
    //we can try to add it

    boolean a = (db.isAddedUser(email, username, password,
                                age, height));
    boolean b = (db.addWeight(db.getIDNumber(email), weight));

    if (!a) {
      messageBody = "add-failed";
      return m = new Message(messageBody);
    }
    if (a && b) {
      messageBody = "added-user";
      return m = new Message(messageBody);
    }
    if (a && !b) {
      messageBody = "added-user-no-weight";
    }


    return m = new Message(messageBody);
  }

  public Message getMealList(String email) {
    data = db.getMealList(email);
    if (data.isEmpty()) {
      messageBody = "no-list-returned";
      return m = new Message(messageBody);
    } else {
      messageBody = "returned-list";
    }
    return m = new Message(messageBody, data);
  }

}