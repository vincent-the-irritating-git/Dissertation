package server_side;

import java.io.Serializable;
import java.util.ArrayList;

public class Message implements Serializable {

  private static final long serialVersionUID = 1L;
  private String message;
  private ArrayList<ArrayList<String>> response = new ArrayList<ArrayList<String>>();

  //so this is the constructor for just messages
  public Message(String message) {

    this.message = message;
    response = null;
  }

  //...and this is the one for both messages and data
  public Message(String message, ArrayList<ArrayList<String>> data) {

    this.message = message;
    response = data;
  }

  public ArrayList<ArrayList<String>> getData() {
    return response;
  }

  public String getMessage() {
    return message;
  }
}
