package server_side;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Dish {

  private StringProperty  name;

  public String getName() {
    return name.get();
  }

  public StringProperty nameProperty() {
    return name;
  }

  public void setName(String name) {
    this.name.set(name);
  }

  public boolean isVegan() {
    return isVegan.get();
  }

  public BooleanProperty isVeganProperty() {
    return isVegan;
  }

  public void setIsVegan(boolean isVegan) {
    this.isVegan.set(isVegan);
  }

  public String getCalories() {
    return calories.get();
  }

  public StringProperty caloriesProperty() {
    return calories;
  }

  public void setCalories(String calories) {
    this.calories.set(calories);
  }

  private BooleanProperty isVegan;
  private StringProperty  calories;

  public Dish() {}

  public Dish(String name, boolean isVegan, String calories) {
    this.name     = new SimpleStringProperty(name);
    this.isVegan  = new SimpleBooleanProperty(isVegan);
    this.calories = new SimpleStringProperty(calories);
  }

  @Override
  public String toString() {
    return getName() + "\n" + isVegan() + "\n" + getCalories();
  }

}
