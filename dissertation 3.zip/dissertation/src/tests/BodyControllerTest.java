package tests;

import dissertation.BodyController;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class BodyControllerTest {

  BodyController bc;

  @BeforeEach
  @Test
  void setUp() throws IOException {
    bc=new BodyController();
  }

  @Test
  @DisplayName("checks if we should display a value for the calorie goal")
  void isCalorieGoalSet() {
    assertFalse(bc.isCalorieGoalSet("0"));
    assertTrue(bc.isCalorieGoalSet("2000"));
  }

}