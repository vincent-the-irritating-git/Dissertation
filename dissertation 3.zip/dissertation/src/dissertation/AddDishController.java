package dissertation;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import server_side.Dish;
import server_side.Message;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.function.Predicate;

public class AddDishController implements Initializable {

  @FXML
  TextField                 searchBar;
  @FXML
  TableView<Dish>           results;
  @FXML
  TableColumn<Dish, String>  name     = new TableColumn<>();
  @FXML
  TableColumn<Dish, Boolean> isVegan  = new TableColumn<>();
  @FXML
  TableColumn<Dish, String>  calories = new TableColumn<>();

  private String space = " ";
  private Socket             socket =
      new Socket("localhost", LoginController.PORT);
  private ObjectOutputStream out    =
      new ObjectOutputStream(socket.getOutputStream());
  private ObjectInputStream  in           =
      new ObjectInputStream(socket.getInputStream());

  private Predicate<Dish> createPredicate(String searchText){
    return dish -> {
      if (searchText == null || searchText.isEmpty()) return true;
      return isSearchFindsDish(dish.getName(), searchText);
    };
  }



  public AddDishController() throws IOException {}

  @Override
  public void initialize(URL url, ResourceBundle resourceBundle) {
    //setting up the table
    name.setCellValueFactory(new PropertyValueFactory<>("name"));
    isVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    calories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    //setting the filtered list up and making the search bar listener
    FilteredList<Dish> filteredData =
        new FilteredList<>(FXCollections.observableList(prepareListForFiltering(
            "veron451@yahoo.co.uk")));
    results.setItems(filteredData);
    searchBar.textProperty().addListener((observable, oldValue, newValue) ->
                                             filteredData.setPredicate(
                                                 createPredicate(newValue))
                                        );
    //making the table be double clickable
    results.setRowFactory(tv -> {
      TableRow<Dish> row = new TableRow<>();
      row.setOnMouseClicked(event -> {
        if (event.getClickCount() == 2 && (!row.isEmpty())) {
          Dish rowData = row.getItem();
          /*do the thing here*/
//          try {
//            Main           main = new Main();
//            BodyController bc   = main.getBodyLoader().getController();
//            bc.test();
//          } catch (IOException e) {
//            e.printStackTrace();
//          }
        }
      });
      return row;
    });
  }

  //this method tests whether or not the words in the field match
  /*must be made private after testing*/
  public static boolean isSearchFindsDish(String dish, String searchText) {
    return dish.toLowerCase().contains(searchText.toLowerCase());
  }

  //this returns our data
  //we then plug this in to the filteredList we define in our variables
  /*must be made private after testing*/
  public List<Dish> prepareListForFiltering(String email) {
    List<Dish>         dish   =new ArrayList<>();
    for (int x=0; x<getListOfMeals(email).size();++x){
      dish.add(new Dish(getListOfMeals(email).get(x).get(0),
               Boolean.parseBoolean(getListOfMeals(email).get(x).get(1)),
               getListOfMeals(email).get(x).get(2)));
    }
    return dish;
  }

  //this gets the list to filter
  /*this is taking the email manually at the moment*/
  public ArrayList<ArrayList<String>> getListOfMeals(String email) {
    ArrayList<ArrayList<String>>nullArray = new ArrayList<>();
    Message message =
        new Message("meals" + space + email);
    try {
      out.writeObject(message);
      out.flush();
      Message messageIn = (Message) in.readObject();
      if (messageIn.getMessage().equals("returned-list")) {
        return messageIn.getData();
      } else {
        return nullArray;
      }
    } catch (IOException | ClassNotFoundException e) {
      e.printStackTrace();
    }
    return nullArray;
  }

  public void createNewDish(){}

}
