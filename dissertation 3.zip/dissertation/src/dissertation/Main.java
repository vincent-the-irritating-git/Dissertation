package dissertation;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;


public class Main extends Application {

    public Main() throws IOException {}

    public static String getEmail() {
        return email;
    }

    public static void setEmail(String email) {
        Main.email = email;
    }

    private static String email;

//    public FXMLLoader getBodyLoader() {
//        return loader;
//    }

    //make the controllers
    //==================================================================
    //Load second scene
//    private FXMLLoader loader = new FXMLLoader(getClass().getResource("fxml" +
//                                                                   "//body.fxml"));
//    private Parent     root   = loader.load();
//    //Get controller of bodyController
//    private BodyController bodyController = loader.getController();
    //==================================================================//

    //==================================================================

    @Override
    public void start(Stage stage) {

        try {
            Parent root  = FXMLLoader.load(getClass().getResource(
                "fxml//body.fxml"));
            Scene  scene = new Scene(root, 891, 574);
//            scene.getStylesheets()
//                 .add(getClass().getResource("application.css")
//                                .toExternalForm());
            stage.setScene(scene);
//            stage.setMaximized(true);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}