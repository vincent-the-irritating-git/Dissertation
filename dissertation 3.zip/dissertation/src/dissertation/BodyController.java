package dissertation;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import server_side.Dish;
import server_side.Message;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;

public class BodyController implements Initializable {

  private Socket             socket =
      new Socket("localhost", LoginController.PORT);
  private ObjectOutputStream out    =
      new ObjectOutputStream(socket.getOutputStream());
  private ObjectInputStream  in     =
      new ObjectInputStream(socket.getInputStream());

  private String space = " ";


  @FXML
  Pane  pane;
  @FXML
  Label calorieGoal;
  /*==================BREAKFAST=====================*/
  @FXML
  TableView<Dish> breakfastTable;
  @FXML
  TableColumn<Dish,String>breakfastName;
  @FXML
  TableColumn<Dish,Boolean>breakfastVegan;
  @FXML
  TableColumn<Dish,String>breakfastCalories;
  private ObservableList<Dish>breakfastList=
      FXCollections.observableArrayList();
  /*===================DINNER========================*/
  @FXML
  TableView<Dish> dinnerTable;
  @FXML
  TableColumn<Dish,String>dinnerName;
  @FXML
  TableColumn<Dish,Boolean>dinnerVegan;
  @FXML
  TableColumn<Dish,String>dinnerCalories;
  private ObservableList<Dish>dinnerList=
      FXCollections.observableArrayList();
  /*================TEA============================*/
  @FXML
  TableView<Dish> teaTable;
  @FXML
  TableColumn<Dish,String>teaName;
  @FXML
  TableColumn<Dish,Boolean>teaVegan;
  @FXML
  TableColumn<Dish,String>teaCalories;
  private ObservableList<Dish>teaList=
      FXCollections.observableArrayList();
  /*================SNACK==========================*/
  @FXML
  TableView<Dish> snackTable;
  @FXML
  TableColumn<Dish,String>snackName;
  @FXML
  TableColumn<Dish,Boolean>snackVegan;
  @FXML
  TableColumn<Dish,String>snackCalories;
  private ObservableList<Dish>snackList=
      FXCollections.observableArrayList();
  /*================PUDDING=======================*/
  @FXML
  TableView<Dish> puddingTable;
  @FXML
  TableColumn<Dish,String>puddingName;
  @FXML
  TableColumn<Dish,Boolean>puddingVegan;
  @FXML
  TableColumn<Dish,String>puddingCalories;
  private ObservableList<Dish>puddingList=
      FXCollections.observableArrayList();
  /*==============================================*/


  public BodyController() throws IOException {}

  @Override
  public void initialize(URL url, ResourceBundle resourceBundle) {

    //set up the tables
    /*==================BREAKFAST=====================*/
    breakfastName.setCellValueFactory(new PropertyValueFactory<>("name"));
    breakfastVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    breakfastCalories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    /*===================DINNER========================*/
    dinnerName.setCellValueFactory(new PropertyValueFactory<>("name"));
    dinnerVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    dinnerCalories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    /*================TEA============================*/
    teaName.setCellValueFactory(new PropertyValueFactory<>("name"));
    teaVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    teaCalories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    /*================PUDDING==========================*/
    puddingName.setCellValueFactory(new PropertyValueFactory<>("name"));
    puddingVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    puddingCalories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    /*================SNACK==========================*/
    snackName.setCellValueFactory(new PropertyValueFactory<>("name"));
    snackVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    snackCalories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    /*===============================================*/

    /*this will keep activating when a bodyController is called!*/
    if (isCalorieGoalSet(getCalories()))
    calorieGoal.setText(getCalories());
    else{
    }

  }

  public void changeDetails(ActionEvent event) {

    ((Node) event.getSource()).getScene().getWindow().hide();
    //so now we load the user page
    //we need a new stage
    Stage stage = new Stage();
    //make an object of it instead of just using FXMLLoader
    FXMLLoader fx = new FXMLLoader();
    //can't have more than one parent, so we use Pane
    try {
      Pane root =
          fx.load(getClass().getResource("fxml//details.fxml").openStream());
      //make a new scene and set the stage with it
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void checkLog(ActionEvent event) {
    ((Node) event.getSource()).getScene().getWindow().hide();
    //so now we load the user page
    //we need a new stage
    Stage stage = new Stage();
    //make an object of it instead of just using FXMLLoader
    FXMLLoader fx = new FXMLLoader();
    //can't have more than one parent, so we use Pane
    try {
      Pane root =
          fx.load(getClass().getResource("fxml//logBook.fxml").openStream());
      //make a new scene and set the stage with it
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  //signs out
  public void signOut() {
    /*
    send a message to the server to
    tell them to close the connexion
     */
    try {
      socket.close();
      out.close();
      in.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
    Platform.exit();
    System.exit(1);
  }

  public void addBreakfast() {

  }

  public void addMeal(){
    openNewWindow("fxml//addDish.fxml");
  }

  public void test(){
    System.out.println("hello ma");
  }

  public void addDinner() {}

  public void addTea() {}

  public void addSnack() {}

  public void addPudding() {}

  //gets the calorie goal of the user.
  //returns 0 if empty
  public String getCalories() {

    try {
      Message message = new Message("get-calories"+space+Main.getEmail());
      out.writeObject(message);
      out.flush();
      Message messageIn=(Message) in.readObject();
      if (Integer.parseInt(messageIn.getMessage())>0){
        return messageIn.getMessage();
      }
    } catch (IOException | ClassNotFoundException e) {
      e.printStackTrace();
    }
    return "0";
  }

  //returns a boolean if we set the calorie goal or not
  public boolean isCalorieGoalSet(String calories){
    return !calories.equals("0");
  }

  public void openNewWindow(String window){
    //to hide
    Stage stage;
    stage = (Stage) pane.getScene().getWindow();
//    stage.hide();
    FXMLLoader loader = new FXMLLoader();
    try {
      Pane root =
          loader.load(getClass().getResource(window).openStream());
      AddDishController ad   = (AddDishController) loader.getController();
      Scene          scene = new Scene(root);
//      scene.getStylesheets()
//           .add(getClass().getResource("application.css").toExternalForm());
      stage.setScene(scene);
      socket.close();
      out.close();
      in.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
    stage.show();
  }

}

