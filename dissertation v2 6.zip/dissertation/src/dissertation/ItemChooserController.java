package dissertation;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import server_side.Item;
import server_side.Message;
import server_side.Protocol;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class ItemChooserController implements Initializable {

  @FXML
  ImageView item1Pic;
  @FXML
  Label item1isVegan;
  @FXML
  Label item1Shop;
  @FXML
  public Label item1Name;

  private final Protocol p =new Protocol();
  private static String                     type;
  public String getType() {
    return type;
  }
  public void setType(String type) {
    ItemChooserController.type = type;
  }

  //gives us the data to set up the table
  //TODO this ain't getting data?
  //.getType apparently isn't working
  private void setUpTable() {
    ArrayList<ArrayList<Item>>items=new ArrayList<>();
    try {
      Main main = new Main();
      SelectItemController sic=
          (SelectItemController) main.getLoader("selectItem");
      items=sic.getItemList();
    }catch (IOException e){e.printStackTrace();}
    //TODO should set 'V' not 0/1
    item1isVegan.setText(String.valueOf(items.get(0).get(0).getIsVegan()));
    item1Shop.setText(String.valueOf(items.get(0).get(0).getShop()));
    item1Name.setText(items.get(0).get(0).getName());
  }

  @Override
  public void initialize(URL url, ResourceBundle resourceBundle) {
    //we need to initialise the table with items found only with the
    // corresponding type
    setUpTable();
  }

}
