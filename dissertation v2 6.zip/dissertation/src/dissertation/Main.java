package dissertation;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;


public class Main extends Application {

    @FXML
    private Pane pane;

    public Main() throws IOException {}

    public static String getEmail() {
        return email;
    }

    public static void setEmail(String email) {
        Main.email = email;
    }

    //TODO DEBUG name
    private static String email="veron451@yahoo.co.uk";


    //==================================================================//

    //==================================================================

    @Override
    public void start(Stage stage) {

        //TODO put back to body
        try {
            Parent root  = FXMLLoader.load(getClass().getResource(
                "fxml//selectItem.fxml"));
            Scene  scene = new Scene(root, 891, 574);
//            scene.getStylesheets()
//                 .add(getClass().getResource("application.css")
//                                .toExternalForm());
            stage.setScene(scene);
//            stage.setMaximized(true);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //our FXMLLoader
    public Object getLoader(String fxmlName){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(
                "fxml" +
                "//"+fxmlName+
                ".fxml"));
            Parent root = loader.load();
            //Get controller of bodyController
            Object ad = loader.getController();
            return ad;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}