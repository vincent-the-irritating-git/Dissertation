package server_side;

import dissertation.Main;
import server_side.Message;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Protocol {

  private Message                      m;
  private String                       messageBody;
  private ArrayList<ArrayList<String>> data;

  private ArrayList<ArrayList<Item>> dataItem;
  private Database                   db    = new Database();

  public Message getM() {
    return m;
  }

  public void protocolToUse(Message message) {
    String[] protocol;
    protocol = message.getMessage().split(" ", 7);
    switch (protocol[0]) {
      default:
        m = new Message("invalid-response");
        return;
      case "signin":
        try {
          signin(protocol[1], protocol[2]);
        } catch (ArrayIndexOutOfBoundsException e) {
          e.printStackTrace();
        }
        return;
      case "register":
        try {
          register(protocol[1], protocol[2], protocol[3], protocol[4],
                   protocol[5], protocol[6]);
        } catch (ArrayIndexOutOfBoundsException | NumberFormatException e) {
          e.printStackTrace();
        }
        return;
      case "get-calories":
        getCalories(protocol[1]);
        return;
      case "meals":
        getMealList(protocol[1]);
        return;
      case "add-dish-to-table":
        addDishToTable(protocol[1], protocol[2], protocol[3], protocol[4]);
        return;
      case "itemChooser-table":
        getItemChooserList(protocol[1]);
        return;
      case "set-the-tables":
        getTodaysFoodEaten(protocol[1]);

    }
  }

  public Message getItemChooserList(String s) {
    db.openDatabase();
    dataItem=db.getItemChooserList(s);
    if (dataItem.isEmpty()){
      messageBody="no-item-list-returned";
    }
    else {
      messageBody = "item-choose-list-returned";
    }
    db.closeDatabase();
    return m=new Message(false,messageBody,dataItem);
  }

  public Message getCalories(String email) {
    db.openDatabase();
    messageBody = String.valueOf(db.getCalories(db.getIDNumber(email)));
    db.closeDatabase();
    return m = new Message(messageBody);
  }

  public Message signin(String email, String password) {
    db.openDatabase();
    if (db.signIn(email, password)) {
      db.getIDNumber(email);
      messageBody = "signed-in";
    } else {
      messageBody = "unknown-user";
    }
    db.closeDatabase();
    return m = new Message(messageBody);
  }

  public Message register(String email, String username, String password,
                          String age, String height, String weight) {
    //we can try to add it
    db.openDatabase();
    boolean a = (db.isAddedUser(email, username, password,
                                age, height));
    boolean b = (db.addWeight(db.getIDNumber(email), weight));

    if (!a) {
      messageBody = "add-failed";
      db.closeDatabase();
      return m = new Message(messageBody);
    }
    if (a && b) {
      messageBody = "added-user";
      db.closeDatabase();
      return m = new Message(messageBody);
    }
    if (a && !b) {
      messageBody = "added-user-no-weight";
    }

    db.closeDatabase();
    return m = new Message(messageBody);
  }

  public Message getMealList(String email) {
    db.openDatabase();
    data = db.getMealList(email);
    if (data.isEmpty()) {
      messageBody = "no-list-returned";
      db.closeDatabase();
      return m = new Message(messageBody);
    } else {
      messageBody = "returned-list";
    }
    db.closeDatabase();
    return m = new Message(messageBody, data);
  }

  public Message addDishToTable(String email, String mealTime, String dishID,
                                String calories) {
    db.openDatabase();
    if (db.isAddDishToTable(email, mealTime, dishID, calories)) {
      messageBody = "dish-added";
    }
    else {
      messageBody = "add-failed";
    }

    db.closeDatabase();
    return m = new Message(messageBody);
  }

  public Message getTodaysFoodEaten(String email) {
    //TODO may need a try catch for null data
    db.openDatabase();
    data = db.getTodaysFoodEaten(email, LocalDate.now().toString());
    if (data.isEmpty()) {
      messageBody = "no-list-returned";
      db.closeDatabase();
      return m = new Message(messageBody);
    } else {
      messageBody = "returned-list";
    }
    db.closeDatabase();
    return m = new Message(messageBody, data);
  }

}