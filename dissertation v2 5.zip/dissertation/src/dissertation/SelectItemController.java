package dissertation;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import server_side.Item;
import server_side.Message;
import server_side.Protocol;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class SelectItemController implements Initializable {

  @FXML
  private Pane                       masterPane;

  @FXML
  private GridPane choiceTable;
  @FXML
  private GridPane bakery;
  @FXML
  private GridPane freshFood;
  @FXML
  private GridPane drinks;
  @FXML
  private GridPane foodCupboard;
  @FXML
  private GridPane frozenReady;
  @FXML
  private GridPane chilledFood;

  @FXML
  private GridPane pane1;
  @FXML
  private GridPane pane2;
  @FXML
  private GridPane pane3;
  @FXML
  private GridPane pane4;
  @FXML
  private GridPane pane5;
  @FXML
  private GridPane pane6;

  @FXML
  private Label choice1;
  @FXML
  private Label choice2;
  @FXML
  private Label choice3;
  @FXML
  private Label choice4;
  @FXML
  private Label choice5;
  @FXML
  private Label choice6;

  private Protocol p=new Protocol();

  @Override
  public void initialize(URL url, ResourceBundle resourceBundle) {

    bakery.setOnMouseEntered(new EventHandler<MouseEvent>() {
      @Override
      public void handle(MouseEvent mouseEvent) {
        showChoices();
        choice1.setText("Bread");
        choice1.setVisible(true);
        choice2.setText("Cakes");
        choice2.setVisible(true);

      }
    });
    choiceTable.setOnMouseExited(mouseEvent -> {
      defaultView();
    });

    freshFood.setOnMouseEntered(new EventHandler<MouseEvent>() {
      @Override
      public void handle(MouseEvent mouseEvent) {
        choice1.setText("'fruit 'n' veg");
        choice1.setVisible(true);
        choice2.setText("\"meat\"");
        choice2.setVisible(true);
      }
    });

    pane1.setOnMouseClicked(MouseEvent->loadItemChooser(choice1.getText()));

  }

  //resets the table clear of columns
  private void defaultView() {
    pane1.setVisible(false);
    pane2.setVisible(false);
    pane3.setVisible(false);
    pane4.setVisible(false);
    pane5.setVisible(false);
    pane6.setVisible(false);
  }

  //shows the columns of the choices
  public void showChoices(){
    pane1.setVisible(true);
    pane1.setGridLinesVisible(true);

    pane2.setVisible(true);
    pane2.setGridLinesVisible(true);

    pane3.setVisible(true);
    pane3.setGridLinesVisible(true);

    pane4.setVisible(true);
    pane4.setGridLinesVisible(true);

    pane5.setVisible(true);
    pane5.setGridLinesVisible(true);

    pane6.setVisible(true);
    pane6.setGridLinesVisible(true);
  }

  public void loadItemChooser(String type) {
    //TODO do this with a loader
    try {
      Main main = new Main();
      ItemChooserController icc   = main.getLoader().getController();
      openNewWindow("fxml//ItemChooser.fxml");
      icc.setType(type);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void openNewWindow(String window) {
    //to hide
    Stage stage;
    stage = (Stage) masterPane.getScene().getWindow();
//    stage.hide();
    FXMLLoader loader = new FXMLLoader();
    try {
      Pane root =
          loader.load(getClass().getResource(window).openStream());
      Scene scene = new Scene(root);
//      scene.getStylesheets()
//           .add(getClass().getResource("application.css").toExternalForm());
      stage.setScene(scene);
    } catch (Exception e) {
      e.printStackTrace();
    }
    stage.show();
  }

}
