package dissertation;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import server_side.Item;
import server_side.Message;
import server_side.Protocol;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class ItemChooserController implements Initializable {

  @FXML
  ImageView item1Pic;
  @FXML
  Label item1isVegan;
  @FXML
  Label item1Shop;
  @FXML
  Label item1Name;

  private ArrayList<ArrayList<Item>> itemList=new ArrayList<>();
  private final Protocol p =new Protocol();
  private static String type;

  @Override
  public void initialize(URL url, ResourceBundle resourceBundle) {
    //we need to initialise the table with items found only with the
    // corresponding type
    setUpTable(type);
//    item1isVegan.setText(String.valueOf(itemList.get(0).get(0).getIsVegan()));
//    item1Shop.setText(String.valueOf(itemList.get(0).get(0).getShop()));
//    item1Name.setText(String.valueOf(itemList.get(0).get(0).getName()));
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    ItemChooserController.type = type;
  }

  //gives us the data to set up the table
  //TODO this ain't getting data?
  //.getType apparently isn't working
  private void setUpTable(String type) {
    Message message=new Message("itemChooser-table"+" "+type);
    p.protocolToUse(message);
    System.out.println(p.getM().getDataItem().toString());

  }

}
