package dissertation;

import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class LoginControllerTest {
LoginController lc=new LoginController();

  LoginControllerTest() throws IOException {}

  @Test
  void isSignInSuccessful() {
    Message message=new Message("signed-in");
    assertTrue(lc.isSignInSuccessful(message));
    message=new Message("rigned-in");
    assertFalse(lc.isSignInSuccessful(message));
  }


}