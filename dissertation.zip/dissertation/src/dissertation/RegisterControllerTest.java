package dissertation;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class RegisterControllerTest {

  RegisterController rc;

  @BeforeEach
  public void setUp() throws IOException {
    rc=new RegisterController();
  }

  @Test
  @DisplayName("Checks if the blank field checker works for the mandatory " +
               "registers")
  public void isBlankFields(){
    String a="a",b="b",c="c";
    String blank="";

    assertFalse(rc.isFieldBlank(a,b,c));
    assertTrue(rc.isFieldBlank(blank,blank,blank));
    assertTrue(rc.isFieldBlank(a,b,blank));
  }

  @Test
  @DisplayName("Checks if passwords match")
  public void isPasswordMatch(){
    String a="a",b="b";

    assertTrue(rc.isPasswordSame(a,a));
    assertFalse(rc.isPasswordSame(a,b));
  }

  @Test
  @DisplayName("checks if values are defaulted to 0")
  public void isNull(){
    assertTrue(rc.isOptionalField0("0","0","0"));
    assertFalse(rc.isOptionalField0("0","0","2"));
  }
}