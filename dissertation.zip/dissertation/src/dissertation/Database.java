package dissertation;

import java.sql.Connection;

public class Database {

  private Connection conn;

  public Connection getConn() {
    return conn;
  }


}




