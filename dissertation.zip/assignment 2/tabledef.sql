CREATE TABLE person(
userID BIGSERIAL PRIMARY KEY,
name varchar(50) NOT NULL,
email varchar(50) NOT NULL UNIQUE CHECK(LENGTH(email)>8 AND email LIKE('%@%')),
age int,
height int,
password varchar(20) NOT NULL, CHECK(LENGTH(password)>4)
);

CREATE TABLE item(
itemID BIGSERIAL PRIMARY KEY,
name varchar(50) NOT NULL,
shop varchar(30),
isVegan boolean NOT NULL CHECK(isSemiVegan=FALSE) DEFAULT FALSE,
isSemiVegan boolean NOT NULL CHECK(isVegan=FALSE) DEFAULT FALSE, 
amount varchar(50),
calories int
);

CREATE TABLE dish(
dishID BIGSERIAL PRIMARY KEY,
name varchar(50) NOT NULL,
preset_calories int CHECK (preset_calories>0)
);

CREATE TABLE itemDish(
dish int REFERENCES dish(dishID) NOT NULL,
item int REFERENCES item(itemID) NOT NULL
);

CREATE TABLE calories (
person int REFERENCES person(userID),
meal varchar (9) CHECK(meal IN('breakfast','dinner','tea','snack','pudding')), 
dish int REFERENCES dish(dishID),
date date NOT NULL DEFAULT CURRENT_DATE,
calories int NOT NULL
);

CREATE TABLE weight(
person int REFERENCES person(userID),
weight int NOT NULL CHECK(weight>0),
date date DEFAULT CURRENT_DATE
);
