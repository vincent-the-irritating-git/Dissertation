package dissertation_server;

import dissertation.Message;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {

  Scanner scanner=new Scanner(System.in);

  private static final int portNo = 44445;

  public static void main(String argv[]) {
    /*so basically, we want the controller to pass the Strings to the client,
     which then sends them off to the server. need the client to wait for
     input in the while loop somehow
     */
    Client c = new Client();

    // Create a socket to connect to the server
    try (Socket clientSocket = new Socket("127.0.0.1", portNo)) {
      System.out.println("Client Running ........");

      //now we have the output stream wrapped around the clientSocket
      ObjectOutputStream out =
          new ObjectOutputStream(clientSocket.getOutputStream());

      //this is the input stream to take in the data message we get from the
      // clientHandler. it's cast as a jabbermessage
      ObjectInputStream in =
          new ObjectInputStream(clientSocket.getInputStream());

      while (true) {
        System.out.println("plz message:");
        Message jabberMessage = new Message(c.scanner.nextLine());
        out.writeObject(jabberMessage);
        out.flush();
        //to handle if there's data or not
        Message jm=new Message(null,null);
        jm=((Message) in.readObject());
        //this is screwing things up
        if (jm.getData()==null){
          System.out.println(jm.getMessage());
        }
        else {
          System.out.println(jm.getMessage() + "\n" + jm.getData());
        }
      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
