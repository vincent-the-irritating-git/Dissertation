package dissertation_server;

import dissertation.Message;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class ProtocolTest {

  public String[]protocolTest;
  Protocol p;

  //assertequals states, "this is what you want, and this
  //is what you get; and what you get you define.

  //so for protocol, getM() is the message we pass, so that's
  //what we test as expected

  @BeforeEach
  void setUp(){
    p=new Protocol();
  }

  @org.junit.jupiter.api.Test
  void signinProtocolToUse() {
    Message message=new Message("signin veron451@yahoo.co.uk sprout");
    p.protocolToUse(message);
    assertEquals("signed-in",p.getM().getMessage());
  }

  @org.junit.jupiter.api.Test
  @DisplayName("checks to see if the protocol array contains what it should")
  void arrayTest() {
    Message  message =new Message("signin veron451@yahoo.co.uk sprout");
    p.protocolToUse(message);
    protocolTest = message.getMessage().split(" ",3);
    assertEquals("signin",protocolTest[0]);
    assertEquals("veron451@yahoo.co.uk",protocolTest[1]);
    assertEquals("sprout",protocolTest[2]);
  }

  @org.junit.jupiter.api.Test
  @DisplayName("checks to see if the protocol selecter works")
  void invalidProtocolToUse() {
    Message message=new Message("do i not like that");
    p.protocolToUse(message);
    assertEquals("invalid-response",p.getM().getMessage());
  }

  @Test
  @DisplayName("checks to see if the new user is added along with a weight or" +
               " not, or not at all")
  void checkAdd(){
    assertEquals("add-failed",p.register("","arriaga",
                                          "arriaga","0", "0","0").getMessage());
    assertEquals("added-user-no-weight",p.register("arruglia@arriaga.com",
                                                    "arriaga",
                                                    "arriaga","0",
                                                    "0","0").getMessage());
    assertEquals("added-user",p.register("barriaga@barriaga.com","arriaga",
                                          "arriaga","0",
                                          "0","160").getMessage());

  }

  @Test
  @AfterAll
  void resetAll(){
    Database db=new Database();
    db.dropTables();
    db.reset();
  }
}