package dissertation_server;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Database {

  private static String dbcommand =
      "jdbc:postgresql://localhost:5432/PlantDiet";
  private static String db        = "postgres";
  private static String pw        = "asda";

  private Connection conn;

  /**
   * Returns the current database connection.
   *
   * @return the database connection.
   */
  public Connection getConnection() {
    return conn;
  }

  /**
   * Default constructor. Connects to the database.
   */
  public Database() {
    connectToDatabase();
    //resetDatabase();
  }

  public void connectToDatabase() {

    try {
      conn = DriverManager.getConnection(dbcommand, db, pw);

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  //takes email and password
  //if they match, return the userid to the client
  //and let them know they can sign in
  public Boolean signIn(String email, String password) {
    String query = "SELECT userid FROM person WHERE email=? AND " +
                   "password=?";
    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.setString(1, email);
      ps.setString(2, password);
      ResultSet rs = ps.executeQuery();
      while (rs.next()) {
        if (!rs.isBeforeFirst()) {
          return true;
        }
      }
    } catch (SQLException throwables) {
      throwables.printStackTrace();
    }
    return false;
  }

  //attempts to add user, does if successful
  public Boolean isAddedUser(String email, String username, String password,
  String age, String height) {
    String query =
        "INSERT INTO PERSON(email, name, password, age, height) VALUES (?,?,?,?,?)";

    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.setString(1, email);
      ps.setString(2, username);
      ps.setString(3, password);
      ps.setInt(4, Integer.parseInt(age));
      ps.setInt(5, Integer.parseInt(height));

      int i = ps.executeUpdate();
      return i > 0;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return false;
  }

  public int getIDNumber(String email){
    String query="SELECT userid FROM person WHERE email=?";
    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.setString(1,email);
      ResultSet rs=ps.executeQuery();
      while (rs.next()){
        return Integer.parseInt(rs.getObject("userid").toString());
      }
    }catch(Exception e){e.printStackTrace();}
    return 255;
  }

  public boolean addWeight(int userid, String weight){
    String query ="INSERT INTO weight (person,weight) VALUES(?,?)";
    try{
      PreparedStatement ps=conn.prepareStatement(query);
      ps.setInt(1, userid);
      ps.setInt(2, Integer.parseInt(weight));
      int i = ps.executeUpdate();
      return i > 0;
      } catch (Exception e) {
      e.printStackTrace();
  }
    return false;
  }

  public void reset(){
    String query="CREATE TABLE person(\n" +
                 "userID BIGSERIAL PRIMARY KEY,\n" +
                 "name varchar(50) NOT NULL,\n" +
                 "email varchar(50) NOT NULL UNIQUE CHECK(LENGTH(email)>8 AND email LIKE('%@%')),\n" +
                 "age int,\n" +
                 "height int,\n" +
                 "password varchar(20) NOT NULL, CHECK(LENGTH(password)>4)\n" +
                 ");\n" +
                 "\n" +
                 "CREATE TABLE item(\n" +
                 "itemID BIGSERIAL PRIMARY KEY,\n" +
                 "name varchar(50) NOT NULL,\n" +
                 "shop varchar(30),\n" +
                 "isVegan boolean NOT NULL CHECK(isSemiVegan=FALSE) DEFAULT FALSE,\n" +
                 "isSemiVegan boolean NOT NULL CHECK(isVegan=FALSE) DEFAULT FALSE, \n" +
                 "amount varchar(50),\n" +
                 "calories int\n" +
                 ");\n" +
                 "\n" +
                 "CREATE TABLE dish(\n" +
                 "dishID BIGSERIAL PRIMARY KEY,\n" +
                 "name varchar(50) NOT NULL,\n" +
                 "preset_calories int CHECK (preset_calories>0)\n" +
                 ");\n" +
                 "\n" +
                 "CREATE TABLE itemDish(\n" +
                 "dish int REFERENCES dish(dishID) NOT NULL,\n" +
                 "item int REFERENCES item(itemID) NOT NULL\n" +
                 ");\n" +
                 "\n" +
                 "CREATE TABLE calories (\n" +
                 "person int REFERENCES person(userID),\n" +
                 "meal varchar (9) CHECK(meal IN('breakfast','dinner','tea','snack','pudding')), \n" +
                 "dish int REFERENCES dish(dishID),\n" +
                 "date date NOT NULL DEFAULT CURRENT_DATE,\n" +
                 "calories int NOT NULL\n" +
                 ");\n" +
                 "\n" +
                 "CREATE TABLE weight(\n" +
                 "person int REFERENCES person(userID),\n" +
                 "weight int NOT NULL CHECK(weight>0),\n" +
                 "date date DEFAULT CURRENT_DATE\n" +
                 ");\n";

    /*
    INSERT INTO person VALUES(1,'Will','veron451@yahoo.co" +
                 ".uk',28,181,'sprout');\nINSERT INTO weight (person,weight) " +
                 "VALUES (1,181);
     */
    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.executeUpdate();
    } catch (SQLException throwables) {
      throwables.printStackTrace();
    }
  }

  public void dropTables() {

    String[] commands = {
        "drop table person cascade;",
        "drop table item cascade;",
        "drop table dish cascade;",
        "drop table itemdish cascade;",
        "drop table calories cascade;",
        "drop table weight cascade;"};

    for (String query : commands) {

      try (PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.executeUpdate();
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
  }

  public void resetDatabase() {

    dropTables();

    ArrayList<String> defs = loadSQL("tabledef");

//    ArrayList<String> data =  loadSQL("jabberdata");

    executeSQLUpdates(defs);
//    executeSQLUpdates(data);
  }

  private void executeSQLUpdates(ArrayList<String> commands) {

    for (String query: commands) {

      try (PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.executeUpdate();
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
  }

  private ArrayList<String> loadSQL(String sqlfile) {

    /*
     * This method is to be used only by the resetDatabase() code.
     * Do not use it yourself to load your own SQL.
     */

    ArrayList<String> commands = new ArrayList<String>();

    try {
      BufferedReader reader = new BufferedReader(new FileReader(sqlfile + ".sql"));

      String command = "";

      String line = "";

      while ((line = reader.readLine())!= null) {

        if (line.contains(";")) {
          command += line;
          command = command.trim();
          commands.add(command);
          command = "";
        }

        else {
          line = line.trim();
          command += line + " ";
        }
      }

      reader.close();

    } catch (IOException e) {
      e.printStackTrace();
    }

    return commands;

  }
}
