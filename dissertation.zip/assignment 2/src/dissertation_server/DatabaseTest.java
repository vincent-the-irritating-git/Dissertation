package dissertation_server;

import org.junit.jupiter.api.*;
import org.postgresql.util.PSQLException;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class DatabaseTest {

  String goodName="veron451@yahoo.co.uk";
  String goodPass="sprout";
  Database db;

  @BeforeEach
  void setUp(){
    db=new Database();
  }

  @Test
  void signInTestGood() {
    assertEquals(true,db.signIn(goodName,goodPass));
  }

  @Test
  void signInTestBad() {
    assertEquals(false, db.signIn(goodPass,"al"));
  }

  @org.junit.jupiter.api.Test
  @DisplayName("checks to see if the userID get method works")
  void checkID() {
    db.getIDNumber(goodName);
    assertEquals(1,db.getIDNumber(goodName));
  }

  @Test
  @DisplayName("checks to see if the weight booleans are correct")
  void checkWeight(){
    boolean a=db.addWeight(1,"150");

    assertTrue(a);
  }

//  @Test
//  void checkWeightThrow() {
//    Assertions.assertThrows(PSQLException.class, () -> db.addWeight(1, "0"));
//  }

  @Test
  void reset(){
    db.resetDatabase();
  }

//  @Test
//  @AfterAll
//  void resetAll(){
//    db.dropTables();
//    db.reset();
//  }


}