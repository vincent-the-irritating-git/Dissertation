INSERT INTO person
VALUES (1,'Will','veron451@yahoo.co.uk',28,181,'sprout',2000);

INSERT INTO person (userID,name,email,age,height,password)
VALUES (2,'Greavsie','greavsie@yahoo.co.uk',81,173,'greavsie');

INSERT INTO weight (person, weight)
VALUES (1, 165);

INSERT INTO item(name,shop,isvegan,amount,calories,type)
VALUES
('brown bread','aldi',true,'loose',100,'bread'),
('ham','tesco',true,'loose',13,'"meat"'),
('ham','sainsburys',true,'loose',13,'"meat"'),
('chicken','tesco',false,'loose',15,'"meat"');

INSERT INTO dish
VALUES(1,'ham sandwich',226),
(2,'chicken sandwich',230),
(3,'ham sandwich',226);

INSERT INTO itemdish
VALUES(1,1),(1,2),
(2,1),(2,4),
(3,1),(3,3);

INSERT INTO calories (person,meal,dish,calories)
VALUES(1,'breakfast',1,226),
 (1,'dinner',1,226),
 (1,'tea',1,226),
 (1,'snack',1,226),
 (1,'pudding',1,226);

