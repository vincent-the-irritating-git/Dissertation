package tests;

import dissertation.RegisterController;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class RegisterControllerTest {

  RegisterController rc;

  @BeforeAll
  public void setUp() throws IOException {
    rc=new RegisterController();
  }

  @Test
  @DisplayName("Checks if the blank field checker works for the mandatory " +
               "registers")
  public void isBlankFields(){
    String a="a",b="b",c="c";
    String blank="";

    assertFalse(rc.isFieldBlank(a,b,c));
    assertTrue(rc.isFieldBlank(blank,blank,blank));
    assertTrue(rc.isFieldBlank(a,b,blank));
  }

  @Test
  @DisplayName("Checks if passwords match")
  public void isPasswordMatch(){
    String a="a",b="b";

    assertTrue(rc.isPasswordSame(a,a));
    assertFalse(rc.isPasswordSame(a,b));
  }

  @Test
  @DisplayName("checks if values are defaulted to 0")
  public void isNull(){
    assertTrue(rc.isOptionalField0("0","0","0"));
    assertFalse(rc.isOptionalField0("0","0","2"));
  }

}