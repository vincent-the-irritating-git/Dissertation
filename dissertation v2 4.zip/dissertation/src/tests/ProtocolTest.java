package tests;

import server_side.Database;
import server_side.Message;
import org.junit.jupiter.api.*;
import server_side.Protocol;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_METHOD)
class ProtocolTest {

  public String[] protocolTest;
  Protocol p;
  String   goodE = "veron451@yahoo.co.uk";

  @BeforeEach
  void setUp() {
    p = new Protocol();
  }

  @Test
  void signinProtocolToUse() {
    Message message = new Message("signin veron451@yahoo.co.uk sprout");
    p.protocolToUse(message);
    assertEquals("signed-in", p.getM().getMessage());
  }

  @Test
  @DisplayName("checks to see if the protocol array contains what it should")
  void arrayTest() {
    Message message = new Message("signin veron451@yahoo.co.uk sprout");
    p.protocolToUse(message);
    protocolTest = message.getMessage().split(" ", 3);
    assertEquals("signin", protocolTest[0]);
    assertEquals(DatabaseTest.goodEmail, protocolTest[1]);
    assertEquals(DatabaseTest.goodPass, protocolTest[2]);
  }

  @Test
  @DisplayName("checks to see if the protocol selecter works")
  void invalidProtocolToUse() {
    Message message = new Message("do i not like that");
    p.protocolToUse(message);
    assertEquals("invalid-response", p.getM().getMessage());
  }

  @Test
  @DisplayName("checks to see if the new user is added along with a weight or" +
               " not, or not at all")
  void checkAdd() {
    /*we need to redo this*/
  }

  @Test
  @DisplayName("checks the calorie get")
  void checkCalories() {
    Message message = new Message("get-calories" + " " + goodE);
    p.protocolToUse(message);
    assertEquals("2000", p.getM().getMessage());
  }

  @Test
  @DisplayName("checks the get meals list")
  void checkMealList() {
    ArrayList<ArrayList<String>> tester     = new ArrayList<>();
    ArrayList<ArrayList<String>> goodTester = new ArrayList<>();
    ArrayList<String> temp     = new ArrayList<>();
    ArrayList<String> goodData = new ArrayList<>();
    goodData.add("1");
    goodData.add("dinner");
    goodData.add("ham sandwich");
    goodData.add("true");
    goodData.add("226");
    goodTester.add(goodData);

    Message message = new Message("meals" + " " + goodE);
    p.protocolToUse(message);

    assertEquals("returned-list", p.getM().getMessage());
    assertEquals(goodTester, p.getM().getData());
    //the bad ones
    Message badMessage = new Message("meals" + " " + "greavsie");
    p.protocolToUse(badMessage);
    assertEquals("no-list-returned", p.getM().getMessage());
    assertNull(p.getM().getData());
  }

  @Test
  @DisplayName("test to see if the add dish to table works")
  void checkAddDishToTable() {
    Message message = new Message("add-dish-to-table" +
                                  " " +
                                  goodE +
                                  " " +
                                  "tea" +
                                  " " +
                                  "1" +
                                  " " +
                                  "400");

    Message badMessage = new Message("add-dish-to-table" +
                                     " " +
                                     "greavsie@yahoo.co.uk" +
                                     " " +
                                     "elevensies" +
                                     " " +
                                     "1" +
                                     " " +
                                     "400");

    p.protocolToUse(message);
    assertEquals("dish-added", p.getM().getMessage());
    p.protocolToUse(badMessage);
    assertEquals("add-failed", p.getM().getMessage());
  }

  @Test
  void getTodayFood(){
    Message message=new Message("set-the-tables"+" "+DatabaseTest.goodEmail);
    p.protocolToUse(message);
    assertEquals("returned-list", p.getM().getMessage());
    //and the expected fails
    Message badMessage=new Message("set-the-tables"+" "+DatabaseTest.badEmail);
    p.protocolToUse(badMessage);
    assertEquals("no-list-returned", p.getM().getMessage());
  }

  @AfterEach
  void reset() {
    Database db=new Database();
    if (db.getConnection() != null) {
      db.closeDatabase();
    }
    db.openDatabase();
    db.resetDatabase("tabledef", "tabledebugdata");
    db.closeDatabase();
  }

}