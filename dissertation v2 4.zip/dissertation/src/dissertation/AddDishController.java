package dissertation;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import server_side.Dish;
import server_side.Message;
import server_side.Protocol;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import java.util.function.Predicate;

public class AddDishController extends Application implements Initializable {

  @FXML
  private Button goBack;
  @FXML
  private Pane pane;
  @FXML
  private TextField                  searchBar;
  @FXML
  private TableView<Dish>            results;
  @FXML
  private TableColumn<Dish, String>  name    = new TableColumn<>();
  @FXML
  private TableColumn<Dish, Boolean> isVegan = new TableColumn<>();
  @FXML
  private TableColumn<Dish, String>  calories = new TableColumn<>();

  private static String             mealTime;
  private final  String             DEBUGEMAIL = "veron451@yahoo.co.uk";
  private        String             space      = " ";
  private Protocol p=new Protocol();

  private FilteredList<Dish> filteredData =
      new FilteredList<>(FXCollections.observableList(prepareListForFiltering(
          DEBUGEMAIL)));

  private Predicate<Dish> createPredicate(String searchText) {
    return dish -> {
      if (searchText == null || searchText.isEmpty()) return true;
      return isSearchFindsDish(dish.getName(), searchText);
    };
  }

  public AddDishController() throws IOException {}

  public String getMealTime() {
    return mealTime;
  }

  public void setMealTime(String mealTime) {
    AddDishController.mealTime = mealTime;
  }

  //=======================================================================================================================

  @Override
  public void initialize(URL url, ResourceBundle resourceBundle) {
    /*DEBUG, NEEDS TO BE GETEMAIL*/
    //setting up the table
    name.setCellValueFactory(new PropertyValueFactory<>("name"));
    isVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    calories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    //setting the filtered list up and making the search bar listener
    results.setItems(filteredData);
    searchBar.textProperty().addListener((observable, oldValue, newValue) ->
                                             filteredData.setPredicate(
                                                 createPredicate(newValue))
                                        );
    //making the table be double clickable
    results.setRowFactory(tv -> {
      TableRow<Dish> row = new TableRow<>();
      row.setOnMouseClicked(event -> {
        if (event.getClickCount() == 2 && (!row.isEmpty())) {
          Dish rowData = row.getItem();
          addDishToMeal(mealTime, rowData);
          openNewWindow("fxml//body.fxml");
        }
      });
      return row;
    });
    //bind method to goBack button
    goBack.setOnAction(EventHandler -> openNewWindow("fxml//body.fxml"));
  }

  @Override
  public void start(Stage stage) throws Exception {

  }
  //========================================================================================================================//

  //this method tests whether or not the words in the field match
  //TODO make private after testing
  public static boolean isSearchFindsDish(String dish, String searchText) {
    return dish.toLowerCase().contains(searchText.toLowerCase());
  }

  //this returns our the data got by getMealList()
  //in dish format
  //TODO make private after testing
  public List<Dish> prepareListForFiltering(String email) {
    ArrayList<ArrayList<String>> listOfLists = getListOfMeals(email);
    List<Dish>                   dish        = new ArrayList<>();
    ArrayList<Integer>IDs=new ArrayList<>();

    for (ArrayList<String> listOfList : listOfLists) {
      Dish singleDish=new Dish(Integer.parseInt(listOfList.get(0)),
                          listOfList.get(1), listOfList.get(2),
                          Integer.parseInt(listOfList.get(3)),
                          listOfList.get(4));
      //should not return duplicate meals here
      if (!IDs.contains(singleDish.getID())){
        dish.add(singleDish);
        IDs.add(singleDish.getID());
      }

    }
    return dish;
  }

  //this gets the list to filter
  //TODO this is taking the email manually at the moment. Bug, won't add
  // duplicate meals to the list with different meal times
  public ArrayList<ArrayList<String>> getListOfMeals(String email) {
    ArrayList<ArrayList<String>> nullArray = new ArrayList<>();
    Message message =
        new Message("meals" + space + email);
    p.protocolToUse(message);
    Message messageIn = p.getM();
    if (messageIn.getMessage().equals("returned-list")) {
      return messageIn.getData();
    } else {
      return nullArray;
    }
  }

  public void createNewDish() {}

  public void addDishToMeal(String name, Dish rowData) {
    Message message =
        new Message("add-dish-to-table" +
                    space +
                    Main.getEmail() +
                    space +
                    name +
                    space +
                    rowData.getID() +
                    space +
                    rowData.getCalories());
    System.out.println(message.getMessage());
    p.protocolToUse(message);
    Message messageIn=p.getM();
    System.out.println(messageIn.getMessage());
  }

  public void openNewWindow(String window){
    //to hide
    Stage stage;
    stage = (Stage) pane.getScene().getWindow();
    stage.hide();
    FXMLLoader loader = new FXMLLoader();
    try {
      Pane root =
          loader.load(getClass().getResource(window).openStream());
      Scene scene = new Scene(root);
//      scene.getStylesheets()
//           .add(getClass().getResource("application.css").toExternalForm());
      stage.setScene(scene);
    } catch (Exception e) {
      e.printStackTrace();
    }
    stage.show();
  }

}
