package dissertation;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import server_side.Message;
import server_side.Protocol;

public class LoginController {

  private String   space = " ";
  private Protocol p     = new Protocol();

  @FXML
  private TextField     email;
  @FXML
  private PasswordField password;
  @FXML
  private Label         signInStatus;
  @FXML
  private Pane          Pane1;


  //signs in if correct email and password
  public void signIn() {
    Message message =
        new Message(
            "signin" +
            space +
            email.getText() +
            space +
            password.getText());
    try {
      p.protocolToUse(message);
      Message messageIn=p.getM();
      //if sign in successful, we go to next scene
      //else we display a message saying 'incorrect...'
      if (isSignInSuccessful(messageIn)) {
        Main.setEmail(email.getText());
        //change scene
        changeScene();
      } else {
        signInStatus.setText("Incorrect username or password");
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public boolean isSignInSuccessful(Message message) {
    if (message.getMessage().equals("signed-in")) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * changes the scene to register window
   */
  public void register() {
    Stage stage;
    stage = (Stage) Pane1.getScene().getWindow();
    stage.hide();

    FXMLLoader loader = new FXMLLoader();
    try {
      Pane root =
          loader.load(getClass().getResource("register.dissertation.fxml")
                                .openStream());
      RegisterController rc    = (RegisterController) loader.getController();
      Scene              scene = new Scene(root);
//        scene.getStylesheets()
//             .add(getClass().getResource("application.css").toExternalForm());
      //changes us to new scene to register
      stage.setScene(scene);
      stage.show();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * what sign in does to the GUI
   */
  public void changeScene() {
    //to hide
    Stage stage;
    stage = (Stage) Pane1.getScene().getWindow();
    stage.hide();
    FXMLLoader loader = new FXMLLoader();
    try {
      Pane root =
          loader.load(getClass().getResource("fxml//body.fxml").openStream());
      BodyController bc    = (BodyController) loader.getController();
      Scene          scene = new Scene(root);
//      scene.getStylesheets()
//           .add(getClass().getResource("application.css").toExternalForm());
      stage.setScene(scene);
    } catch (Exception e) {
      e.printStackTrace();
    }
    stage.show();
  }

}