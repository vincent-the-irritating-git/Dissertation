package dissertation;

import javafx.application.Platform;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import server_side.Dish;
import server_side.Message;
import server_side.Protocol;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class BodyController implements Initializable {

  private String   space = " ";
  private String   mealName;
  private Protocol p     = new Protocol();

  @FXML
  private ProgressBar                progressBar;
  @FXML
  private Pane                       pane;
  @FXML
  private Label                      calorieGoal;
  /*==================BREAKFAST=====================*/
  @FXML
  private Label                      breakfastCaloriesTotal;
  @FXML
  private Label                      breakfastVeganLabel;
  @FXML
  private TableView<Dish>            breakfastTable;
  @FXML
  private TableColumn<Dish, String>  breakfastName;
  @FXML
  private TableColumn<Dish, Boolean> breakfastVegan;
  @FXML
  private TableColumn<Dish, String>  breakfastCalories;
  private ObservableList<Dish>       breakfastList =
      FXCollections.observableArrayList();
  /*===================DINNER========================*/
  @FXML
  private Label                      dinnerCaloriesTotal;
  @FXML
  private Label                      dinnerVeganLabel;
  @FXML
  private TableView<Dish>            dinnerTable;
  @FXML
  private TableColumn<Dish, String>  dinnerName;
  @FXML
  private TableColumn<Dish, Boolean> dinnerVegan;
  @FXML
  private TableColumn<Dish, String>  dinnerCalories;
  private ObservableList<Dish>       dinnerList    =
      FXCollections.observableArrayList();
  /*================TEA============================*/
  @FXML
  private Label                      teaCaloriesTotal;
  @FXML
  private Label                      teaVeganLabel;
  @FXML
  private TableView<Dish>            teaTable;
  @FXML
  private TableColumn<Dish, String>  teaName;
  @FXML
  private TableColumn<Dish, Boolean> teaVegan;
  @FXML
  private TableColumn<Dish, String>  teaCalories;
  private ObservableList<Dish>       teaList       =
      FXCollections.observableArrayList();
  /*================SNACK==========================*/
  @FXML
  private Label                      snackCaloriesTotal;
  @FXML
  private Label                      snackVeganLabel;
  @FXML
  private TableView<Dish>            snackTable;
  @FXML
  private TableColumn<Dish, String>  snackName;
  @FXML
  private TableColumn<Dish, Boolean> snackVegan;
  @FXML
  private TableColumn<Dish, String>  snackCalories;
  private ObservableList<Dish>       snackList     =
      FXCollections.observableArrayList();
  /*================PUDDING=======================*/
  @FXML
  private Label                      puddingCaloriesTotal;
  @FXML
  private Label                      puddingVeganLabel;
  @FXML
  private TableView<Dish>            puddingTable;
  @FXML
  private TableColumn<Dish, String>  puddingName;
  @FXML
  private TableColumn<Dish, Boolean> puddingVegan;
  @FXML
  private TableColumn<Dish, String>  puddingCalories;
  private ObservableList<Dish>       puddingList   =
      FXCollections.observableArrayList();
  /*==============================================*/

  @Override
  public void initialize(URL url, ResourceBundle resourceBundle) {

    //set up the tables
    /*==================BREAKFAST=====================*/
    breakfastName.setCellValueFactory(new PropertyValueFactory<>("name"));
    breakfastVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    breakfastCalories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    /*===================DINNER========================*/
    dinnerName.setCellValueFactory(new PropertyValueFactory<>("name"));
    dinnerVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    dinnerCalories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    /*================TEA============================*/
    teaName.setCellValueFactory(new PropertyValueFactory<>("name"));
    teaVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    teaCalories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    /*================PUDDING==========================*/
    puddingName.setCellValueFactory(new PropertyValueFactory<>("name"));
    puddingVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    puddingCalories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    /*================SNACK==========================*/
    snackName.setCellValueFactory(new PropertyValueFactory<>("name"));
    snackVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    snackCalories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    /*===============================================*/

    //TODO could this be done better?
    try {
      setTables();
    }catch (NullPointerException e){e.printStackTrace();}

    if (isCalorieGoalSet(getCalories()))
      calorieGoal.setText(getCalories());
    else {
    }

    //TODO set the labels for if the meal time was vegan or not with a picture
    setLabelIsVegan(breakfastList, breakfastVeganLabel);
    setLabelIsVegan(dinnerList, dinnerVeganLabel);
    setLabelIsVegan(teaList, teaVeganLabel);
    setLabelIsVegan(snackList, snackVeganLabel);
    setLabelIsVegan(puddingList, puddingVeganLabel);

    setUpCalorieTotals();
    setUpProgressBar();
  }

  //  loads all the lists into the relevant tables and sets all the tables in
//  initialise
  /* this won't allow us to set multiples of the same item per meal time*/
  public void setTables() {
    try {
      Main main = new Main();
      AddDishController ad =
          main.getLoader().getController();
      List<Dish>listOfMealData=
          convertStringToDish(getDataForTables());

      for (Dish dish : listOfMealData) {
        if (dish.getTime().equals("breakfast")) {
          breakfastList.add(dish);
        }
        if (dish.getTime().equals("dinner")) {
          dinnerList.add(dish);
        }
        if (dish.getTime().equals("tea")) {
          teaList.add(dish);
        }
        if (dish.getTime().equals("pudding")) {
          puddingList.add(dish);
        }
        if (dish.getTime().equals("snack")) {
          snackList.add(dish);
        }
        breakfastTable.setItems(breakfastList);
        dinnerTable.setItems(dinnerList);
        teaTable.setItems(teaList);
        puddingTable.setItems(puddingList);
        snackTable.setItems(snackList);
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  //gets the data to set the tables in initialise
  public ArrayList<ArrayList<String>>getDataForTables(){
    Message message = new Message("set-the-tables" + space + Main.getEmail());
    p.protocolToUse(message);
    return p.getM().getData();
  }

  public void changeDetails(ActionEvent event) {

    ((Node) event.getSource()).getScene().getWindow().hide();
    //so now we load the user page
    //we need a new stage
    Stage stage = new Stage();
    //make an object of it instead of just using FXMLLoader
    FXMLLoader fx = new FXMLLoader();
    //can't have more than one parent, so we use Pane
    try {
      Pane root =
          fx.load(getClass().getResource("fxml//details.fxml").openStream());
      //make a new scene and set the stage with it
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void checkLog(ActionEvent event) {
    ((Node) event.getSource()).getScene().getWindow().hide();
    //so now we load the user page
    //we need a new stage
    Stage stage = new Stage();
    //make an object of it instead of just using FXMLLoader
    FXMLLoader fx = new FXMLLoader();
    //can't have more than one parent, so we use Pane
    try {
      Pane root =
          fx.load(getClass().getResource("fxml//logBook.fxml").openStream());
      //make a new scene and set the stage with it
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  //signs out
  public void signOut() {
    //TODO send a message to the server to tell them to close the connexion
    String  body    = "sign-out";
    Message message = new Message(body);
    p.protocolToUse(message);
    Platform.exit();
    System.exit(1);
  }

  public void addMeal() {
    openNewWindow("fxml//addDish.fxml");
  }

  public void addBreakfast() {
    mealName = "breakfast";
    try {
      Main              main = new Main();
      AddDishController ad   = main.getLoader().getController();
      addMeal();
      ad.setMealTime(mealName);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void addDinner() {
    mealName = "dinner";
    try {
      Main              main = new Main();
      AddDishController ad   = main.getLoader().getController();
      addMeal();
      ad.setMealTime(mealName);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void addTea() {
    mealName = "tea";
    try {
      Main              main = new Main();
      AddDishController ad   = main.getLoader().getController();
      addMeal();
      ad.setMealTime(mealName);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void addSnack() {
    mealName = "snack";
    try {
      Main              main = new Main();
      AddDishController ad   = main.getLoader().getController();
      addMeal();
      ad.setMealTime(mealName);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void addPudding() {
    mealName = "pudding";
    try {
      Main              main = new Main();
      AddDishController ad   = main.getLoader().getController();
      addMeal();
      ad.setMealTime(mealName);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  //gets the calorie goal of the user.
  //returns 0 if empty
  public String getCalories() {

    Message message = new Message("get-calories" + space + Main.getEmail());
    p.protocolToUse(message);
    Message messageIn = p.getM();
    if (Integer.parseInt(messageIn.getMessage()) > 0) {
      return messageIn.getMessage();
    }
    return "0";
  }

  //returns a boolean if we set the calorie goal or not
  public boolean isCalorieGoalSet(String calories) {
    return !calories.equals("0");
  }

  public void openNewWindow(String window) {
    //to hide
    Stage stage;
    stage = (Stage) pane.getScene().getWindow();
//    stage.hide();
    FXMLLoader loader = new FXMLLoader();
    try {
      Pane root =
          loader.load(getClass().getResource(window).openStream());
      Scene scene = new Scene(root);
//      scene.getStylesheets()
//           .add(getClass().getResource("application.css").toExternalForm());
      stage.setScene(scene);
    } catch (Exception e) {
      e.printStackTrace();
    }
    stage.show();
  }

  public void setLabelIsVegan(ObservableList<Dish> list, Label label) {
    if (list.isEmpty()) {
    } else
      for (Dish dish : list) {
        if (dish.isVegan() == 0) {
          label.setText("Ve");
          label.setStyle("-fx-text-fill: blue;");
        } else {
          label.setText("V");
          label.setStyle("-fx-text-fill: green;");
        }
        label.setFont(Font.font("Courier New", FontWeight.BOLD,
                                FontPosture.REGULAR, 30));
        label.setVisible(true);
      }
  }

  public void removeItemFromTable() {

  }

  public List<Dish> convertStringToDish(ArrayList<ArrayList<String>>strings){
    List<Dish>listOfMealData=new ArrayList<>();
    for (ArrayList<String> stringDish:strings) {
      listOfMealData.add(new Dish(Integer.parseInt(stringDish.get(0)),
                                  stringDish.get(1),
                                  stringDish.get(2),
                                  Integer.parseInt(stringDish.get(3)),
                                  stringDish.get(4)));
    }
    return listOfMealData;
  }

  public void setUpCalorieTotals() {
    //breakfast
    int x = 0;
    for (Dish dish : breakfastList) {
      x += Integer.parseInt(dish.getCalories());
    }
    SimpleStringProperty xVal = new SimpleStringProperty(String.valueOf(x));
    breakfastCaloriesTotal.textProperty().bind(xVal);
    if (Integer.parseInt(breakfastCaloriesTotal.getText()) != 0) {
      breakfastCaloriesTotal.setVisible(true);
    }
    //dinner
    int y = 0;
    for (Dish dish : dinnerList) {
      y += Integer.parseInt(dish.getCalories());
    }
    SimpleStringProperty yVal = new SimpleStringProperty(String.valueOf(y));
    dinnerCaloriesTotal.textProperty().bind(yVal);
    if (Integer.parseInt(dinnerCaloriesTotal.getText()) != 0) {
      dinnerCaloriesTotal.setVisible(true);
    }
    //tea
    int z = 0;
    for (Dish dish : teaList) {
      z += Integer.parseInt(dish.getCalories());
    }
    SimpleStringProperty zVal = new SimpleStringProperty(String.valueOf(z));
    teaCaloriesTotal.textProperty().bind(zVal);
    if (Integer.parseInt(teaCaloriesTotal.getText()) != 0) {
      teaCaloriesTotal.setVisible(true);
    }
    //snack
    int a = 0;
    for (Dish dish : snackList) {
      a += Integer.parseInt(dish.getCalories());
    }
    SimpleStringProperty aVal = new SimpleStringProperty(String.valueOf(a));
    snackCaloriesTotal.textProperty().bind(aVal);
    if (Integer.parseInt(snackCaloriesTotal.getText()) != 0) {
      snackCaloriesTotal.setVisible(true);
    }
    //pudding
    int b = 0;
    for (Dish dish : puddingList) {
      b += Integer.parseInt(dish.getCalories());
    }
    SimpleStringProperty bVal = new SimpleStringProperty(String.valueOf(b));
    puddingCaloriesTotal.textProperty().bind(bVal);
    if (Integer.parseInt(puddingCaloriesTotal.getText()) != 0) {
      puddingCaloriesTotal.setVisible(true);
    }
  }

  public void setUpProgressBar(){
    //TODO finish doing the progress bar; try and add colours to it?
    int[] calorieTotals = new int[6];
    try {
      calorieTotals[0] = Integer.parseInt(breakfastCaloriesTotal.getText());
      calorieTotals[1] = Integer.parseInt(dinnerCaloriesTotal.getText());
      calorieTotals[2] = Integer.parseInt(teaCaloriesTotal.getText());
      calorieTotals[3] = Integer.parseInt(snackCaloriesTotal.getText());
      calorieTotals[4] = Integer.parseInt(puddingCaloriesTotal.getText());
      calorieTotals[5] =
          calorieTotals[0] +
          calorieTotals[1] +
          calorieTotals[2] +
          calorieTotals[3] +
          calorieTotals[4];
    } catch (NumberFormatException | NullPointerException e) {
      e.printStackTrace();
    }
    SimpleDoubleProperty calorieTotal =
        new SimpleDoubleProperty(calorieTotals[5]/Double.parseDouble(calorieGoal.getText()));
    progressBar.progressProperty().bind(calorieTotal);
  }

  }


