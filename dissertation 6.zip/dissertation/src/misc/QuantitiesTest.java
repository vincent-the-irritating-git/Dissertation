package misc;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class QuantitiesTest extends Quantities {

  Quantities q;

  @BeforeEach
  @Test
  void setUp() {
    q = new QuantitiesTest();
  }

  @Test
  @DisplayName("checks if the container is loading the right quantity options")
  void enumTestValues() {
    ArrayList<Quantities.quantity> vals2 = new ArrayList<>();
    assertEquals(vals2, q.enumTest("salad fingers"));
    vals2.clear();
    vals2.add(quantity.WHOLE);
    vals2.add(quantity.HALF);
    vals2.add(quantity.THIRD);
    vals2.add(quantity.QUARTER);
    assertEquals(vals2, q.enumTest("bag"));
    vals2.clear();
    vals2.add(quantity.TABLESPOON);
    vals2.add(quantity.TEASPOON);
    assertEquals(vals2, q.enumTest("spoon"));
    vals2.clear();
    vals2.add(quantity.GLASS);
    assertEquals(vals2, q.enumTest("bottle"));
    vals2.clear();
    vals2.add(quantity.WHOLE);
    assertEquals(vals2, q.enumTest("whole bottle"));
  }

}