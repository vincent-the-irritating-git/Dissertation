package dissertation;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import server_side.Message;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class RegisterController {

  private Socket             socket =
      new Socket("localhost", LoginController.PORT);
  private   ObjectOutputStream out    =
      new ObjectOutputStream(socket.getOutputStream());
  private   ObjectInputStream  in     =
      new ObjectInputStream(socket.getInputStream());
  private String    space = " ";
  @FXML
  private Label     status;
  @FXML
  private TextField username;
  @FXML
  private TextField email;
  @FXML
  private PasswordField password;
  @FXML
  private PasswordField confirmPassword;
  @FXML
  private TextField age;
  @FXML
  private TextField height;
  @FXML
  private TextField weight;

  public RegisterController() throws IOException {}

//TODO some instructions should appear on the screen if we get add-failed
  //sends a message to the server
  //registering a new user.
  //all this needs to check is if the passwords are
  //the same. the db checks the email.
  public void register() {
    //this is checking if any of the fields are blank
    if (isFieldBlank(email.getText(),
                         username.getText(),
                         password.getText())) {
      status.setText("E-mail, Username and Password cannot be blank");
      return;
    }
    //this checks if the passwords match
    if (!isPasswordSame(password.getText(), confirmPassword.getText())) {
      status.setText("Passwords don't match");
      return;
    }
    //set defaults for teh other values if they aren't used
    if (age.getText().isEmpty())
      age.setText("0");
    if (height.getText().isEmpty())
      height.setText("0");
    if (weight.getText().isEmpty())
      weight.setText("0");
    //now we make the message
    Message message =
        new Message("register" +
                    space +
                    email.getText() +
                    space +
                    username.getText() +
                    space +
                    password.getText() +
                    space +
                    age.getText() +
                    space +
                    height.getText() +
                    space +
                    weight.getText());
    try {
      out.writeObject(message);
      out.flush();
      Message messageIn = (Message) in.readObject();
      System.out.println("message: " + messageIn.getMessage());
      if (messageIn.getMessage().equals("add-failed")){
        //put the GUI code in here that show
        //the prompts on the screen
      }
    } catch (Exception e) {
      e.printStackTrace();
    }

  }



  //checks if any mandatory field is blank
  public Boolean isFieldBlank(String email, String username,
                                 String password){
    email=this.email.getText();
    username=this.username.getText();
    password=this.password.getText();
    return email.isEmpty() || username.isEmpty() || password.isEmpty();
  }

  //checks if any optional field is blank
  public Boolean isOptionalField0(String age, String height,
                                 String weight){
    age=this.age.getText();
    height=this.height.getText();
    weight=this.weight.getText();
    return age.equals("0") && height.equals("0") && weight.equals("0");
  }

  //checks if the passwords match
  public Boolean isPasswordSame(String password, String confirm){
    password=this.password.getText();
    confirm=this.confirmPassword.getText();
    return password.equals(confirm);
  }

  //if the first or second value matches the first or second value,
  //print it.


}
