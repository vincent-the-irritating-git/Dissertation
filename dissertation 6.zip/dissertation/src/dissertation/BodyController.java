package dissertation;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import server_side.Dish;
import server_side.Message;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class BodyController implements Initializable {

  private Socket             socket =
      new Socket("localhost", LoginController.PORT);
  private ObjectOutputStream out    =
      new ObjectOutputStream(socket.getOutputStream());
  private ObjectInputStream  in     =
      new ObjectInputStream(socket.getInputStream());

  private String space = " ";
  private       String             mealName;

  @FXML
  private Pane      pane;
  @FXML
  private Label calorieGoal;
  /*==================BREAKFAST=====================*/
  @FXML
  private Label breakfastVeganLabel;
  @FXML
  private TableView<Dish> breakfastTable;
  @FXML
  private TableColumn<Dish,String>breakfastName;
  @FXML
  private TableColumn<Dish,Boolean>breakfastVegan;
  @FXML
  private TableColumn<Dish,String>breakfastCalories;
  private ObservableList<Dish>breakfastList=
      FXCollections.observableArrayList();
  /*===================DINNER========================*/
  @FXML
  private Label dinnerVeganLabel;
  @FXML
  private TableView<Dish> dinnerTable;
  @FXML
  private TableColumn<Dish,String>dinnerName;
  @FXML
  private  TableColumn<Dish,Boolean>dinnerVegan;
  @FXML
  private TableColumn<Dish,String>dinnerCalories;
  private ObservableList<Dish>dinnerList=
      FXCollections.observableArrayList();
  /*================TEA============================*/
  @FXML
  private Label teaVeganLabel;
  @FXML
  private TableView<Dish> teaTable;
  @FXML
  private TableColumn<Dish,String>teaName;
  @FXML
  private TableColumn<Dish,Boolean>teaVegan;
  @FXML
  private TableColumn<Dish,String>teaCalories;
  private ObservableList<Dish>teaList=
      FXCollections.observableArrayList();
  /*================SNACK==========================*/
  @FXML
  private Label snackVeganLabel;
  @FXML
  private TableView<Dish> snackTable;
  @FXML
  private TableColumn<Dish,String>snackName;
  @FXML
  private TableColumn<Dish,Boolean>snackVegan;
  @FXML
  private  TableColumn<Dish,String>snackCalories;
  private ObservableList<Dish>snackList=
      FXCollections.observableArrayList();
  /*================PUDDING=======================*/
  @FXML
  private Label puddingVeganLabel;
  @FXML
  private  TableView<Dish> puddingTable;
  @FXML
  private  TableColumn<Dish,String>puddingName;
  @FXML
  private  TableColumn<Dish,Boolean>puddingVegan;
  @FXML
  private TableColumn<Dish,String>puddingCalories;
  private ObservableList<Dish>puddingList=
      FXCollections.observableArrayList();
  /*==============================================*/


  public BodyController() throws IOException {}

  @Override
  public void initialize(URL url, ResourceBundle resourceBundle) {

    //set up the tables
    /*==================BREAKFAST=====================*/
    breakfastName.setCellValueFactory(new PropertyValueFactory<>("name"));
    breakfastVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    breakfastCalories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    /*===================DINNER========================*/
    dinnerName.setCellValueFactory(new PropertyValueFactory<>("name"));
    dinnerVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    dinnerCalories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    /*================TEA============================*/
    teaName.setCellValueFactory(new PropertyValueFactory<>("name"));
    teaVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    teaCalories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    /*================PUDDING==========================*/
    puddingName.setCellValueFactory(new PropertyValueFactory<>("name"));
    puddingVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    puddingCalories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    /*================SNACK==========================*/
    snackName.setCellValueFactory(new PropertyValueFactory<>("name"));
    snackVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    snackCalories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    /*===============================================*/

    setTables();

    //TODO this will keep activating when a bodyController is called!
    if (isCalorieGoalSet(getCalories()))
    calorieGoal.setText(getCalories());
    else{
    }

    //TODO set the labels for if the meal time was vegan or not with a picture
    setLabelIsVegan(breakfastList,breakfastVeganLabel);
    setLabelIsVegan(dinnerList,dinnerVeganLabel);
    setLabelIsVegan(teaList,teaVeganLabel);
    setLabelIsVegan(snackList,snackVeganLabel);
    setLabelIsVegan(puddingList,puddingVeganLabel);
    }


//  loads all the lists into the relevant tables and sets all the tables in
//  initialise
  public void setTables() {
    try {
      Main main = new Main();
      AddDishController ad =
          main.getLoader().getController();
      List<Dish> listOfMealData = ad.prepareListForFiltering(Main.getEmail());
      for (Dish dish:listOfMealData){
        if(dish.getTime().equals("breakfast")){
          breakfastList.add(dish);
        }
        if(dish.getTime().equals("dinner")){
          dinnerList.add(dish);
        }
        if(dish.getTime().equals("tea")){
          teaList.add(dish);
        }
        if(dish.getTime().equals("pudding")){
          puddingList.add(dish);
        }
        if(dish.getTime().equals("snack")){
          snackList.add(dish);
        }
        breakfastTable.setItems(breakfastList);
        dinnerTable.setItems(dinnerList);
        teaTable.setItems(teaList);
        puddingTable.setItems(puddingList);
        snackTable.setItems(snackList);
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void changeDetails(ActionEvent event) {

    ((Node) event.getSource()).getScene().getWindow().hide();
    //so now we load the user page
    //we need a new stage
    Stage stage = new Stage();
    //make an object of it instead of just using FXMLLoader
    FXMLLoader fx = new FXMLLoader();
    //can't have more than one parent, so we use Pane
    try {
      Pane root =
          fx.load(getClass().getResource("fxml//details.fxml").openStream());
      //make a new scene and set the stage with it
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void checkLog(ActionEvent event) {
    ((Node) event.getSource()).getScene().getWindow().hide();
    //so now we load the user page
    //we need a new stage
    Stage stage = new Stage();
    //make an object of it instead of just using FXMLLoader
    FXMLLoader fx = new FXMLLoader();
    //can't have more than one parent, so we use Pane
    try {
      Pane root =
          fx.load(getClass().getResource("fxml//logBook.fxml").openStream());
      //make a new scene and set the stage with it
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  //signs out
  public void signOut() {
    //TODO send a message to the server to tell them to close the connexion
    try {
      socket.close();
      out.close();
      in.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
    Platform.exit();
    System.exit(1);
  }

  public void addMeal(){
    openNewWindow("fxml//addDish.fxml");
  }

  public void addBreakfast() {
    mealName="breakfast";
    try {
      Main           main = new Main();
      AddDishController ad   = main.getLoader().getController();
      addMeal();
      ad.setMealTime(mealName);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void addDinner() {
    mealName="dinner";
    try {
      Main           main = new Main();
      AddDishController ad   = main.getLoader().getController();
      addMeal();
      ad.setMealTime(mealName);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void addTea() {
    mealName="tea";
    try {
      Main           main = new Main();
      AddDishController ad   = main.getLoader().getController();
      addMeal();
      ad.setMealTime(mealName);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void addSnack() {
    mealName="snack";
    try {
      Main           main = new Main();
      AddDishController ad   = main.getLoader().getController();
      addMeal();
      ad.setMealTime(mealName);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void addPudding() {
    mealName="pudding";
    try {
      Main           main = new Main();
      AddDishController ad   = main.getLoader().getController();
      addMeal();
      ad.setMealTime(mealName);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  //gets the calorie goal of the user.
  //returns 0 if empty
  public String getCalories() {

    try {
      Message message = new Message("get-calories"+space+Main.getEmail());
      out.writeObject(message);
      out.flush();
      Message messageIn=(Message) in.readObject();
      if (Integer.parseInt(messageIn.getMessage())>0){
        return messageIn.getMessage();
      }
    } catch (IOException | ClassNotFoundException e) {
      e.printStackTrace();
    }
    return "0";
  }

  //returns a boolean if we set the calorie goal or not
  public boolean isCalorieGoalSet(String calories){
    return !calories.equals("0");
  }

  public void openNewWindow(String window){
    //to hide
    Stage stage;
    stage = (Stage) pane.getScene().getWindow();
//    stage.hide();
    FXMLLoader loader = new FXMLLoader();
    try {
      Pane root =
          loader.load(getClass().getResource(window).openStream());
      Scene          scene = new Scene(root);
//      scene.getStylesheets()
//           .add(getClass().getResource("application.css").toExternalForm());
      stage.setScene(scene);
      socket.close();
      out.close();
      in.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
    stage.show();
  }

  public void setLabelIsVegan(ObservableList<Dish>list,Label label) {
    if (list.isEmpty()) {
    } else
      for (Dish dish : list) {
        if (!dish.isVegan()) {
          label.setText("Ve");
          label.setStyle("-fx-text-fill: blue;");
        } else {
          label.setText("V");
          label.setStyle("-fx-text-fill: green;");
        }
        label.setFont(Font.font("Courier New", FontWeight.BOLD,
                                FontPosture.REGULAR,30));
        label.setVisible(true);
      }
  }

}

