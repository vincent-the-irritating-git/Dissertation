package tests;

import dissertation.AddDishController;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import server_side.Dish;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class AddDishControllerTest {

  public static final String DEBUG_EMAIL     = "veron451@yahoo.co.uk";
  public static final String DEBUG_BAD_EMAIL = "greavsie@yahoo.co.uk";

  AddDishController ad;
  private final Dish DEBUG_DISH = new Dish(1,"dinner","ham sandwich", true,
                                           "226");


  @BeforeEach
  void setUp() throws IOException {
    ad = new AddDishController();
  }

  @Test
  @DisplayName("checks to see if the search boolean works")
  void checkSearchBoolean() {
    assertFalse(ad.isSearchFindsDish(DEBUG_DISH.getName(), "pease pudding"));
    assertFalse(ad.isSearchFindsDish(DEBUG_DISH.getName(), "gypsy creams"));
    assertTrue(ad.isSearchFindsDish(DEBUG_DISH.getName(), "ham sandwich"));
    assertTrue(ad.isSearchFindsDish(DEBUG_DISH.getName(), "ham"));
  }

  @Test
  @DisplayName("checks to see if we get the list")
  void checkReturnList() {
    ArrayList<String> blank = new ArrayList<>();
    ArrayList<String> test = new ArrayList<>();
    test.add(String.valueOf(DEBUG_DISH.getId()));
    test.add("dinner");
    test.add(DEBUG_DISH.getName());
    test.add(String.valueOf(DEBUG_DISH.isVegan()));
    test.add(DEBUG_DISH.getCalories());
    assertEquals(test, ad.getListOfMeals(DEBUG_EMAIL).get(0));
    assertEquals(blank,ad.getListOfMeals(DEBUG_BAD_EMAIL));
  }

  void listToArray(){}

  @Test
  @DisplayName("checks to see the list that we feed into our filter list")
  void checkList() {
    List<Dish> test = new ArrayList<>();
    test.add(DEBUG_DISH);
    assertEquals(test.toString(),
                 ad.prepareListForFiltering(DEBUG_EMAIL).toString());
  }

}