package server_side;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Dish {

  private StringProperty  name;

  public String getName() {
    return name.get();
  }

  public StringProperty nameProperty() {
    return name;
  }

  public void setName(String name) {
    this.name.set(name);
  }

  public boolean isVegan() {
    return isVegan.get();
  }

  public BooleanProperty isVeganProperty() {
    return isVegan;
  }

  public void setIsVegan(boolean isVegan) {
    this.isVegan.set(isVegan);
  }

  public String getCalories() {
    return calories.get();
  }

  public StringProperty caloriesProperty() {
    return calories;
  }

  public void setCalories(String calories) {
    this.calories.set(calories);
  }

  private BooleanProperty isVegan;
  private StringProperty  calories;

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  private int id =255;

  public String getTime() {
    return time;
  }

  public void setTime(String time) {
    this.time = time;
  }

  private String time;

  public Dish() {}

  public Dish(int id, String time, String name, boolean isVegan,
              String calories) {
    this.id=id;
    this.time=time;
    this.name     = new SimpleStringProperty(name);
    this.isVegan  = new SimpleBooleanProperty(isVegan);
    this.calories = new SimpleStringProperty(calories);
  }

  @Override
  public String toString() {
    return getName() + "\n" + isVegan() + "\n" + getCalories();
  }

}
