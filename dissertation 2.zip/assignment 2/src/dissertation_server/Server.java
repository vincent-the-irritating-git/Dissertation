package dissertation_server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Server {

  private static       ServerSocket server = null;
  private static       Database     db     = new Database();
  private static final int          portNo = 44445;


  public static void main(String[] argv) throws IOException {
    /**if the ServerSocket has opened a connexion on the port specified
     *
     */
    if (startServer()) {
      System.out.println("--Server connexion established--");
    } else {
      System.out.println("problem, squire");
      return;
    }
    /**check connexion to db
     *
     */
    isConnected();
    /**infinite loop to keep listening to requests
     *
     */
    processClientRequests();
    try {
      server.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public static boolean startServer() {

    /**Server is listening on port
     *
     */
    try {
      server = new ServerSocket(portNo);
      server.setReuseAddress(true);
    } catch (IOException e) {
      e.printStackTrace();
      return false;
    }
    return true;

  }

  public static synchronized void processClientRequests() throws IOException {
    try {
      while (true) {
        Thread.sleep(300);
        Socket clientSocket = null;

        clientSocket = server.accept();
        ClientHandler handler = new ClientHandler(clientSocket);

        new Thread(handler).start();

        System.out.println("--ClientHandler started--");
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      server.close();
    }
  }

  public static void isConnected() {
    if (establishDBConnection()) {
      System.out.println("--Server successfully connected to the database--");
    } else {
      System.err.println("--Connexion to database not established!--");
    }
  }

  public static boolean establishDBConnection() {
    /**Update the following with your postgres id and password
     *
     */
    String USER_NAME = "postgres";
    String PASSWORD  = "asda";
      /**this is where we register the driver
       * the Class.forName() method dynamically loads the driver's
       * class file into memory and registers it
       */
    try {
      Class.forName("org.postgresql.Driver");

      Connection connexion = db.getConnection();
      /**this is where we pick the database
       */
      connexion = DriverManager.getConnection("jdbc:postgresql://localhost:5432/PlantDiet",
                                              USER_NAME,
                                              PASSWORD);
      return connexion.isValid(2);// 2 second timeout

    } catch (SQLException e) {
      e.printStackTrace();
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    }
    return false;

  }

}