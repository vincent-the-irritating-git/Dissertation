package dissertation_server;

import dissertation.Message;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class ProtocolTest {

  public String[]protocolTest;
  Protocol p;
  String goodE="veron451@yahoo.co.uk";

  @BeforeEach
  void setUp(){
    p=new Protocol();
  }

  @org.junit.jupiter.api.Test
  void signinProtocolToUse() {
    Message message=new Message("signin veron451@yahoo.co.uk sprout");
    p.protocolToUse(message);
    assertEquals("signed-in",p.getM().getMessage());
  }

  @org.junit.jupiter.api.Test
  @DisplayName("checks to see if the protocol array contains what it should")
  void arrayTest() {
    Message  message =new Message("signin veron451@yahoo.co.uk sprout");
    p.protocolToUse(message);
    protocolTest = message.getMessage().split(" ",3);
    assertEquals("signin",protocolTest[0]);
    assertEquals(DatabaseTest.goodName,protocolTest[1]);
    assertEquals(DatabaseTest.goodPass,protocolTest[2]);
  }

  @org.junit.jupiter.api.Test
  @DisplayName("checks to see if the protocol selecter works")
  void invalidProtocolToUse() {
    Message message=new Message("do i not like that");
    p.protocolToUse(message);
    assertEquals("invalid-response",p.getM().getMessage());
  }

  @Test
  @DisplayName("checks to see if the new user is added along with a weight or" +
               " not, or not at all")
  void checkAdd(){
    assertEquals("add-failed",p.register("","arriaga",
                                          "arriaga","0", "0","0").getMessage());
    assertEquals("added-user-no-weight",p.register("arruglia@arriaga.com",
                                                    "arriaga",
                                                    "arriaga","0",
                                                    "0","0").getMessage());
    assertEquals("added-user",p.register("barriaga@barriaga.com","arriaga",
                                          "arriaga","0",
                                          "0","160").getMessage());

  }

  @Test
  @DisplayName("checks the calorie get")
  void checkCalories(){
    Message message=new Message("get-calories"+" "+goodE);
    p.protocolToUse(message);
    assertEquals("2000",p.getM().getMessage());
  }

  @Test
  @AfterAll
  void reset(){
    Database db=new Database();
    db.resetDatabase("tabledef","tabledebugdata");
  }
}