package dissertation_server;

import org.junit.jupiter.api.*;
import org.postgresql.util.PSQLException;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class DatabaseTest {

  static String goodName="veron451@yahoo.co.uk";
  static String goodPass="sprout";
  Database db;

  @BeforeEach
  void setUp(){
    db=new Database();
  }

  @Test
  void signInTestGood() {
    assertEquals(true,db.signIn(goodName,goodPass));
  }

  @Test
  void signInTestBad() {
    assertEquals(false, db.signIn(goodPass,"al"));
  }

  @org.junit.jupiter.api.Test
  @DisplayName("checks to see if the userID get method works")
  void checkID() {
    db.getIDNumber(goodName);
    assertEquals(1,db.getIDNumber(goodName));
  }

  @Test
  @DisplayName("checks to see if the weight booleans are correct")
  void checkWeight(){
    boolean a=db.addWeight(1,"150");

    assertTrue(a);
  }

//  @Test
//  void checkWeightThrow() {
//    Assertions.assertThrows(Exception.class, () -> db.addWeight(1, "0"));
//  }

  @Test
  @DisplayName("checks the get calorie goal method")
  void checkCalorieGoal(){
    assertEquals(2000,db.getCalories(1));
    assertNotEquals(2000,db.getCalories(2));
    assertEquals(0,db.getCalories(2));
  }

  @Test
  @AfterAll
  void reset(){
    db.dropTables();
    db.resetDatabase("tabledef","tabledebugdata");
  }

}