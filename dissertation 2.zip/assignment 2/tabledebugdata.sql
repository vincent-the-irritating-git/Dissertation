INSERT INTO person
VALUES (1,'Will','veron451@yahoo.co.uk',28,181,'sprout',2000);

INSERT INTO person
VALUES (2,'Greavsie','greavsie@yahoo.co.uk',81,173,'greavsie');

INSERT INTO weight (person, weight)
VALUES (1, 165);