package dissertation;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import server_side.Message;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class LoginController {

  public static final int                PORT   = 44445;
  private             Socket             socket =
      new Socket("localhost", PORT);
  private             ObjectOutputStream out    =
      new ObjectOutputStream(socket.getOutputStream());
  private             ObjectInputStream  in     =
      new ObjectInputStream(socket.getInputStream());

  private String space = " ";

  public LoginController() throws IOException {}

  @FXML
  TextField     email;
  @FXML
  PasswordField password;
  @FXML
  Label signInStatus;
  @FXML
  Pane  Pane1;


  //signs in if correct email and password
  public void signIn() {
    Message message =
        new Message(
        "signin" +
                    space +
                    email.getText() +
                    space +
                    password.getText());
//            "signin veron451@yahoo.co.uk sprout");
    try {
      out.writeObject(message);
      out.flush();
      Message messageIn = (Message) in.readObject();
      System.out.println("message: " + messageIn.getMessage());
      //if sign in successful, we go to next scene
      //else we display a message saying 'incorrect...'
      if (isSignInSuccessful(messageIn)) {
        Main.setEmail(email.getText());
        //change scene
        changeScene();
      } else {
        signInStatus.setText("Incorrect username or password");
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public boolean isSignInSuccessful(Message message) {
    if (message.getMessage().equals("signed-in")) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * changes the scene to register window
   */
  public void register() {
    Stage stage;
    stage = (Stage) Pane1.getScene().getWindow();
    stage.hide();

    FXMLLoader loader = new FXMLLoader();
    try {
      Pane root =
          loader.load(getClass().getResource("register.dissertation.fxml").openStream());
      RegisterController rc    = (RegisterController) loader.getController();
      Scene              scene = new Scene(root);
//        scene.getStylesheets()
//             .add(getClass().getResource("application.css").toExternalForm());
      out.close();
      in.close();
      socket.close();
      //changes us to new scene to register
      stage.setScene(scene);
      stage.show();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * what sign in does to the GUI
   */
  public void changeScene() {
    //to hide
    Stage stage;
    stage = (Stage) Pane1.getScene().getWindow();
    stage.hide();
    FXMLLoader loader = new FXMLLoader();
    try {
      Pane root =
          loader.load(getClass().getResource("body.dissertation.fxml").openStream());
      BodyController bc    = (BodyController) loader.getController();
      Scene          scene = new Scene(root);
//      scene.getStylesheets()
//           .add(getClass().getResource("application.css").toExternalForm());
      stage.setScene(scene);
      socket.close();
      out.close();
      in.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
    stage.show();
  }

}