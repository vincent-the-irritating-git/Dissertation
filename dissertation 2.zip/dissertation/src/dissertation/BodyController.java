package dissertation;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import server_side.Message;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;

public class BodyController implements Initializable {

  private Socket             socket =
      new Socket("localhost", LoginController.PORT);
  private ObjectOutputStream out    =
      new ObjectOutputStream(socket.getOutputStream());
  private ObjectInputStream  in     =
      new ObjectInputStream(socket.getInputStream());

  private String space = " ";


  @FXML
  Pane  pane;
  @FXML
  Label calorieGoal;

  public BodyController() throws IOException {}

  @Override
  public void initialize(URL url, ResourceBundle resourceBundle) {

  }

  public void changeDetails(ActionEvent event) {

    ((Node) event.getSource()).getScene().getWindow().hide();
    //so now we load the user page
    //we need a new stage
    Stage stage = new Stage();
    //make an object of it instead of just using FXMLLoader
    FXMLLoader fx = new FXMLLoader();
    //can't have more than one parent, so we use Pane
    try {
      Pane root =
          fx.load(getClass().getResource("fxml//details.fxml").openStream());
      //make a new scene and set the stage with it
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void checkLog() {}

  public void signOut() {}

  public void addBreakfast() {}

  public void addDinner() {}

  public void addTea() {}

  public void addSnack() {}

  public void addPudding() {}

  //gets the calorie goal of the user.
  //returns 0 if empty
  public int getCalories() {
    Message message = new Message("get-calories"+space+Main.getEmail());
    try {
      out.writeObject(message);
      out.flush();
      Message messageIn=(Message) in.readObject();
      if (Integer.parseInt(messageIn.getMessage())>0){
        return Integer.parseInt(messageIn.getMessage());
      }
    } catch (IOException | ClassNotFoundException e) {
      e.printStackTrace();
    }
    return 0;
  }

}

