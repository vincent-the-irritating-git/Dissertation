package tests;

import dissertation.LoginController;
import dissertation.Main;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import server_side.Message;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class LoginControllerTest {
LoginController lc =new LoginController();

  LoginControllerTest() throws IOException {}

  @Test
  void isSignInSuccessful() {
    Message message =new Message("signed-in");
    assertTrue(lc.isSignInSuccessful(message));
    message=new Message("rigned-in");
    assertFalse(lc.isSignInSuccessful(message));
  }

  @Test
  @DisplayName("checks if the static email in Main works")
  void isCheckStaticEmail(){
    Main.setEmail("jeff-astle");
    assertEquals("jeff-astle",Main.getEmail());
    assertNotEquals("pele",Main.getEmail());
  }

}