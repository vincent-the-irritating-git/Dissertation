INSERT INTO person
VALUES (1,'Will','veron451@yahoo.co.uk',28,181,'sprout',2000);

INSERT INTO person (userID,name,email,age,height,password)
VALUES (2,'Greavsie','greavsie@yahoo.co.uk',81,173,'greavsie');

INSERT INTO weight (person, weight)
VALUES (1, 165);

INSERT INTO item(name,shop,isvegan,amount,calories,type)
VALUES
('brown bread','Aldi',true,'loose',100,'bread'),
('ham','Tesco',true,'loose',13,'"meat"'),
('ham','Sainsburys',false,'loose',13,'"meat"'),
('chicken','Tesco',true,'loose',15,'"meat"'),
('pasta','Aldi',true,'bag',1000,'pasta'),
('sugar','Kwik Save',true,'spoon',65,'sugar and preserves'),
('bakewell tart','debug',true,'loose',389,'cakes'),
('carrot (m)','debug',true,'loose',27,'fruit + veg'),
('plum (m)','debug',true,'loose',25,'fruit + veg'),
('tangerine (m)','debug',true,'loose',29,'fruit + veg'),
('nectarine (m)','debug',true,'loose',56,'fruit + veg'),
('oranges (m)','debug',true,'loose',54,'fruit + veg'),
('red apple (m)','debug',true,'loose',51,'fruit + veg'),
('banana (m)','debug',true,'loose',81,'fruit + veg'),
('red pepper (m)','debug',true,'loose',34,'fruit + veg'),
('potato (m)','debug',true,'loose',164,'fruit + veg'),
('yellow pepper (m)','debug',true,'loose',37,'fruit + veg'),
('pear (m)','debug',true,'loose',67,'fruit + veg'),
('peach (m)','debug',true,'loose',36,'fruit + veg'),
('green apple (m)','debug',true,'loose',48,'fruit + veg'),
('red onion (m)','debug',true,'loose',57,'fruit + veg'),
('courgette (m)','debug',true,'loose',26,'fruit + veg'),
('aubergine (m)','debug',true,'loose',45,'fruit + veg'),
('leek (m)','debug',true,'loose',21,'fruit + veg'),
('white onion (l)','debug',true,'loose',53,'fruit + veg'),
('sweet potato (m)','debug',true,'loose',131,'fruit + veg');

INSERT INTO dish
VALUES(1,'ham sandwich',226),
(2,'chicken sandwich',230),
(3,'ham sandwich',226),
(4,'rich evans surprise',400);

INSERT INTO itemdish (dish,item)
VALUES(1,1),(1,2),
(2,1),(2,4),
(3,1),(3,3),
(4,1);

INSERT INTO calories (person,meal,dish,calories,date)
VALUES(1,'breakfast',1,226,'2021-08-03'),
 (1,'dinner',1,226,'2021-08-03'),
 (1,'tea',1,226,'2021-08-03'),
 (1,'snack',1,226,'2021-08-03'),
 (1,'pudding',1,226,'2021-08-03'),
 (1,'dinner',2,230,'2021-08-03');



