package tests;

import org.junit.jupiter.api.*;
import server_side.Database;
import server_side.Dish;
import server_side.Item;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_METHOD)
class DatabaseTest {

  static  String                     goodEmail = "veron451@yahoo.co.uk";
  static  String                     badEmail  = "fucker@lol.com";
  static  String                     goodPass  = "sprout";
  private Database                   db        = null;
  private ArrayList<ArrayList<Dish>> blankDish = new ArrayList<>();
  private ArrayList<ArrayList<Item>> blankItem = new ArrayList<>();


  @BeforeEach
  void setUp() {
    db = new Database();
    db.openDatabase();
  }

  @Test
  void signInTestGood() {
    assertEquals(true, db.signIn(goodEmail, goodPass));
  }

  @Test
  void signInTestBad() {
    assertEquals(false, db.signIn(goodPass, "al"));
  }

  @Test
  @DisplayName("checks to see if the userID get method works")
  void checkID() {
    db.getIDNumber(goodEmail);
    assertEquals(1, db.getIDNumber(goodEmail));
  }

  @Test
  @DisplayName("checks to see if the weight booleans are correct")
  void checkWeight() {
    boolean a = db.addWeight(1, "150");

    assertTrue(a);
  }

//  @Test
//  void checkWeightThrow() {
//    Assertions.assertThrows(Exception.class, () -> db.addWeight(1, "0"));
//  }

  @Test
  @DisplayName("checks the get calorie goal method")
  void checkCalorieGoal() {
    assertEquals(2000, db.getCalories(1));
    assertNotEquals(2000, db.getCalories(2));
    assertEquals(0, db.getCalories(2));
  }

  @Test
  @DisplayName("checks the getMealList() method, should return every meal " +
               "they've" +
               " eaten")
  void checkGetMeals() {
    ArrayList<ArrayList<Dish>> blankDish = new ArrayList<>();

    assertNotEquals(blankDish, db.getMealList(goodEmail));
    assertNotNull(db.getMealList(goodEmail));
  }

  @Test
  @DisplayName("checks to see if the table update by double clicking works " +
               "and sends to calories table")
  void checkIsAddToTable() {
    assertTrue(db.isAddDishToTable(goodEmail, "dinner", "1", "300"));
//    assertFalse(db.isAddDishToTable("greavsie", "tea", "5", "450"));
  }

  @Test
  @DisplayName("checks to see if the method returns the food eaten on the date " +
               "specified")
  void checkGetTodaysFood() {
    assertNotEquals(blankDish, db.getTodaysFoodEaten(goodEmail, "2021-08-03"));
    assertNotNull(db.getTodaysFoodEaten(goodEmail,"2021-08-03"));
    assertNotEquals(blankDish,
                    db.getTodaysFoodEaten(goodEmail,
                                          LocalDate.now().toString()));
    assertNull(db.getTodaysFoodEaten(goodEmail, "2021-08-02"));
  }

  @Test
  @DisplayName("checks to see if the itemChooser method returns the correct " +
               "list of Items")
  void checkGetItemChooser() {
    assertNotEquals(blankItem, db.getItemChooserList("bread"));
    assertNotEquals(blankItem, db.getItemChooserList("\"meat\""));
    assertEquals(blankItem, db.getItemChooserList("rich evans"));
    assertNotEquals(blankItem, db.getItemChooserList("fruit + veg"));

  }

  @Test
  @DisplayName("checks the ItemChooser by keyword")
  void checkItemChooserKeyword() {
    assertNotEquals(blankItem, db.getItemChooserListKeyword("ham"));
    assertNotEquals(blankItem, db.getItemChooserListKeyword("ha"));
    assertNotEquals(blankItem, db.getItemChooserListKeyword("am"));
    assertNotEquals(blankItem, db.getItemChooserListKeyword("brown brea"));
    assertEquals(blankItem, db.getItemChooserListKeyword("rich evans"));
  }

  @Test
  @DisplayName("checks the temp table add and creation")
  void checkTempAdd() {
//    assertTrue(db.isAddItemToDish(1));
  }

  @Test
  @DisplayName("check the item list for the temp table")
  void checkTempList() {
    assertNotEquals(blankItem, db.getTempItems());
  }

  @Test
  @DisplayName("check if the tempDish update is working")
  void checkTempDish() throws SQLException {
    assertTrue(db.saveTempDish(5, 56, "THIRD"));
  }

  @Test
  @DisplayName("check removeTempDishItem(int)")
  void checkRemoveItem(){
    assertTrue(db.removeTempDishItem(1));
    assertFalse(db.removeTempDishItem(-1));
  }

  @Test
  @DisplayName("checks if removeFromCaloriesTable(int, String) has succeeded")
  void checkRemoveFromCalories(){
    assertTrue(db.removeFromCaloriesTable(1,"breakfast"));
    assertFalse(db.removeFromCaloriesTable(99,"tea"));
    assertFalse(db.removeFromCaloriesTable(0,"rich evans"));
  }

  @Test
  @DisplayName("checks to see if we can retrieve preset amounts in tempDish")
  void checkCaloriesAndAmounts() {
    ArrayList<String> blank = new ArrayList<>();
    assertNotEquals(blank, db.getAmount(5));
    assertNotEquals(null, db.getAmount(5));
    String HALF = "HALF";
    assertEquals(HALF, db.getAmount(5).get(0));
  }

  @Test
  @DisplayName("checks to see if we can retrieve preset amounts for editable " +
               "items in tempDish")
  void checkCaloriesAndAmountsEditable() {
    ArrayList<String> blank = new ArrayList<>();
    assertNotEquals(blank, db.getAmount(1));
    assertNotEquals(null, db.getAmount(1).get(0));
  }

  @Test
  @DisplayName("checks to see if the tempDish save works")
  void checkSaveTempDish() {
    assertTrue(db.saveNewDish("chocolate surprise", 670));
  }

  @Test
  @DisplayName("check the total from tempDish")
  void getTempDishCalories() {
    assertNotEquals(-1, db.getTempDishCalories());
  }

  @AfterEach
  void reset() {
    if (db.getConnection() != null) {
      db.closeDatabase();
    }
    db.openDatabase();
    db.resetDatabase("tabledef", "tabledebugdata");
    db.closeDatabase();
  }

}