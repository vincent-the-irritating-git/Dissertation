package server_side;

import dissertation.AddDishController;

import java.time.LocalDate;
import java.util.ArrayList;

public class Protocol {

  private Message                      m;
  private String                       messageBody;
  private ArrayList<ArrayList<String>> data;
  private ArrayList<ArrayList<Dish>> dataDish;
  private ArrayList<ArrayList<Item>> dataItem;
  private Database                   db    = new Database();

  public Message getM() {
    return m;
  }

  public void protocolToUse(Message message) {
    String[] protocol;
    protocol = message.getMessage().split(" ", 7);
    switch (protocol[0]) {
      default:
        m = new Message("invalid-response");
        return;
      case "signin":
        try {
          signin(protocol[1], protocol[2]);
        } catch (ArrayIndexOutOfBoundsException e) {
          e.printStackTrace();
        }
        return;
      case "register":
        try {
          register(protocol[1], protocol[2], protocol[3], protocol[4],
                   protocol[5], protocol[6]);
        } catch (ArrayIndexOutOfBoundsException | NumberFormatException e) {
          e.printStackTrace();
        }
        return;
      case "get-calories":
        getCalories(protocol[1]);
        return;
        //TODO get rid of the emails
      case "meals":
        getMealList(protocol[1]);
        return;
      case "add-dish-to-table":
        addDishToTable(protocol[1], protocol[2], protocol[3], protocol[4]);
        return;
      case "itemChooser-table":
        String[]rejoin2=message.getMessage().split(" ",2);
        System.out.println(rejoin2[1]);
        getItemChooserList(rejoin2[1].toLowerCase());
        return;
        //this is for choosing by name not type
      case "itemChooser-table-keyword":
        String[]rejoin=message.getMessage().split(" ",2);
        getItemChooserListKeyword(rejoin[1].toLowerCase());
        return;
      case "add-item-to-new-dish":
        addItemToDish(Integer.parseInt(protocol[1]));
        return;
      case "get-temp-items":
        getTempItems();
        return;
      case "save-tempDish-values":
        try {
          saveTempDish(Integer.parseInt(protocol[1]),
                       Integer.parseInt(protocol[2]),
                       protocol[3]);
        }catch (NullPointerException e){e.printStackTrace();
          messageBody="tempDish-did-not-save";
          m=new Message(messageBody);
        }
        return;
      case "get-calories-and-amounts":
        getCaloriesAndAmounts(Integer.parseInt(protocol[1]));
        return;
      case "drop-tempDish":
        dropTempDish();
        return;
      case "save-new-tempDish":
        saveNewDish(protocol[1],Integer.parseInt(protocol[2]));
        return;
      case "get-tempDish-calories":
        getTempDishCalories();
        return;
        case "remove-temp-dish-item":
          removeTempDishItem(Integer.parseInt(protocol[1]));
          return;
      case "remove-from-today's-food":
        removeFromCaloriesTable(Integer.parseInt(protocol[1]),protocol[2]);
        return;
      case "set-the-tables":
        getTodaysFoodEaten(protocol[1]);
    }
  }

  public Message removeFromCaloriesTable(int id, String meal){
    db.openDatabase();
    if(db.removeFromCaloriesTable(id,meal)){
      messageBody="removed-successfully";
    }
    else{
      messageBody="dish-not-removed";
    }
    db.closeDatabase();
    return m=new Message(messageBody);
  }

  public Message removeTempDishItem(int id){
    db.openDatabase();
    if(db.removeTempDishItem(id)){
      messageBody="item-removed";
    }
    else{
      messageBody="item-not-removed";
    }
    db.closeDatabase();
    return m=new Message(messageBody);
  }

  public Message getTempDishCalories(){
    db.openDatabase();
    if(db.getTempDishCalories()==-1){
      messageBody="calories-not-returned";
    }
    else{
      messageBody=String.valueOf(db.getTempDishCalories());
    }
    db.closeDatabase();
    return m=new Message(messageBody);
  }

  //this saves the tempDish values in add table into the itemDish table and then
  //into the dish table before deleting everything.
  public Message saveNewDish(String name, int cals) {
    db.openDatabase();
    if (db.saveNewDish(AddDishController.spacer(name), cals)) {
      messageBody = "tempDish-added-to-dish-successfully";
    } else {
      messageBody = "tempDish-did-not-add";
    }
    db.closeDatabase();
    return m=new Message(messageBody);
  }

  public Message dropTempDish(){
    db.openDatabase();
    db.dropTempDish();
    db.closeDatabase();
    return m=new Message("tempDish-table-reset");
  }

  public Message getCaloriesAndAmounts(int id){
    db.openDatabase();
    ArrayList<ArrayList<String>>wrapperJohn=new ArrayList<>();
    wrapperJohn.add(db.getAmount(id));
    db.closeDatabase();
    if(wrapperJohn.get(0)==null){
      messageBody="no-data-returned";
    }
    else {
      data        = wrapperJohn;
      messageBody = "calories-and-amounts-returned";
    }
    return m=new Message(messageBody,data);
  }

  public Message saveTempDish(int id, int calories, String amount){
    db.openDatabase();
    if(db.saveTempDish(id,calories,amount)){
      messageBody="tempDish-saved";
    }
    else {
      messageBody = "tempDish-did-not-save";
    }
    db.closeDatabase();
    return m=new Message(messageBody);
  }

  public Message getTempItems(){
    db.openDatabase();
    dataItem=db.getTempItems();
    db.closeDatabase();
    if (!dataItem.isEmpty()){
     messageBody="item-list-returned";
    }
    else{
      messageBody="no-items-returned";
    }
    return m=new Message(false,messageBody,dataItem);
  }

  public Message addItemToDish(int id) {
    db.openDatabase();
    boolean add = db.isAddItemToDish(id);
    db.closeDatabase();
    if (add) {
      return m = new Message("dish-added-to-to-temp");
    } else {
      return m = new Message("add-failed");
    }
  }

  public Message getItemChooserListKeyword(String keyword){
    db.openDatabase();
    dataItem=db.getItemChooserListKeyword(keyword);
    db.closeDatabase();
    if (dataItem.isEmpty()){
      messageBody="no-item-list-returned";
    }
    else {
      messageBody = "item-choose-list-returned";
    }
    return m=new Message(false,messageBody,dataItem);
  }

  public Message getItemChooserList(String type) {
    db.openDatabase();
    dataItem=db.getItemChooserList(type);
    db.closeDatabase();
    if (dataItem.isEmpty()){
      messageBody="no-item-list-returned";
    }
    else {
      messageBody = "item-choose-list-returned";
    }
    return m=new Message(false,messageBody,dataItem);
  }

  public Message getCalories(String email) {
    db.openDatabase();
    messageBody = String.valueOf(db.getCalories(db.getIDNumber(email)));
    db.closeDatabase();
    return m = new Message(messageBody);
  }

  public Message signin(String email, String password) {
    db.openDatabase();
    if (db.signIn(email, password)) {
      db.getIDNumber(email);
      messageBody = "signed-in";
    } else {
      messageBody = "unknown-user";
    }
    db.closeDatabase();
    return m = new Message(messageBody);
  }

  public Message register(String email, String username, String password,
                          String age, String height, String weight) {
    //we can try to add it
    db.openDatabase();
    boolean a = (db.isAddedUser(email, username, password,
                                age, height));
    boolean b = (db.addWeight(db.getIDNumber(email), weight));

    if (!a) {
      messageBody = "add-failed";
      db.closeDatabase();
      return m = new Message(messageBody);
    }
    if (a && b) {
      messageBody = "added-user";
      db.closeDatabase();
      return m = new Message(messageBody);
    }
    if (a && !b) {
      messageBody = "added-user-no-weight";
    }

    db.closeDatabase();
    return m = new Message(messageBody);
  }

  public Message getMealList(String email) {
    db.openDatabase();
    dataDish = db.getMealList(email);
    db.closeDatabase();
    if ((dataDish==null)||(dataDish.isEmpty())) {
      messageBody = "no-list-returned";
      return m = new Message(messageBody);
    } else {
      messageBody = "returned-list";
    }
    return m = new Message(false,false,messageBody, dataDish);
  }

  public Message addDishToTable(String email, String mealTime, String dishID,
                                String calories) {
    db.openDatabase();
    if (db.isAddDishToTable(email, mealTime, dishID, calories)) {
      messageBody = "dish-added";
    }
    else {
      messageBody = "add-failed";
    }

    db.closeDatabase();
    return m = new Message(messageBody);
  }

  public Message getTodaysFoodEaten(String email) {
    //TODO may need a try catch for null data
    db.openDatabase();
    dataDish = db.getTodaysFoodEaten(email, LocalDate.now().toString());
    db.closeDatabase();
    if ((dataDish==null)||(dataDish.isEmpty())) {
      messageBody = "no-list-returned";
      return m = new Message(messageBody);
    } else {
      messageBody = "returned-list";
    }
    return m = new Message(false,false,messageBody, dataDish);
  }

  public void resetDatabase(){
    db.openDatabase();
    db.resetDatabase("tabledef", "tabledebugdata");
    db.closeDatabase();
  }

}