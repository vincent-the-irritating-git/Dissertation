package server_side;

import misc.Quantities;

import javax.swing.plaf.nimbus.State;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class Database {

  private Connection conn=null;

  /**
   * Returns the current database connection.
   *
   * @return the database connection.
   */
  public Connection getConnection() {
    return conn;
  }

  /**
   * Default constructor. Connects to the database.
   */
  public Database() {
  }

  public void openDatabase() {

    try {
        Class.forName("org.sqlite.JDBC");
        conn = DriverManager.getConnection("jdbc:sqlite:PlantDiet.db");
        System.out.println("Connexion established!");
    } catch (SQLException | ClassNotFoundException throwables) {
      throwables.printStackTrace();
    }
  }

  public void closeDatabase() {
    try {
      conn.close();
      System.out.println("Connexion closed!");
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }


  //takes email and password
  //if they match, return the userid to the client
  //and let them know they can sign in
  public Boolean signIn(String email, String password) {
    String query = "SELECT userid FROM person WHERE email=? AND " +
                   "password=?";
    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.setString(1, email);
      ps.setString(2, password);
      ResultSet rs = ps.executeQuery();
      while (rs.next()) {
        if (!rs.isBeforeFirst()) {
          return true;
        }
      }
    } catch (SQLException throwables) {
      throwables.printStackTrace();
    }
    return false;
  }

  //attempts to add user, does if successful
  public Boolean isAddedUser(String email, String username, String password,
  String age, String height) {
    String query =
        "INSERT INTO PERSON(email, name, password, age, height) VALUES (?,?,?,?,?)";

    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.setString(1, email);
      ps.setString(2, username);
      ps.setString(3, password);
      ps.setInt(4, Integer.parseInt(age));
      ps.setInt(5, Integer.parseInt(height));

      int i = ps.executeUpdate();
      return i > 0;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return false;
  }

  public int getIDNumber(String email){
    String query="SELECT userid FROM person WHERE email=?";
    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.setString(1,email);
      ResultSet rs=ps.executeQuery();
      while (rs.next()){
        return Integer.parseInt(rs.getObject("userid").toString());
      }
    }catch(Exception e){e.printStackTrace();}
    return -1;
  }

  public boolean addWeight(int userid, String weight){
    String query ="INSERT INTO weight (person,weight) VALUES(?,?)";
    try{
      PreparedStatement ps=conn.prepareStatement(query);
      ps.setInt(1, userid);
      ps.setInt(2, Integer.parseInt(weight));
      int i = ps.executeUpdate();
      return i > 0;
      } catch (Exception e) {
      e.printStackTrace();
  }
    return false;
  }

  public int getCalories(int userid) {
    String query = "SELECT calorie_goal FROM person WHERE userid=?";

    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.setInt(1, userid);
      ResultSet rs = ps.executeQuery();
      while (rs.next()) {
        return (int) rs.getObject("calorie_goal");
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return 0;
  }

  public ArrayList<ArrayList<String>> getMealList(String email) {

    //TODO is this working? should return all meals a person has eaten

    String query ="SELECT dish.dishID,dish.name, meal, CASE MIN(isVegan) WHEN" +
                  " 0 " +
                  "THEN 0 ELSE 1 END vegan, preset_calories FROM dish JOIN " +
                  "itemDish ON dish" +
                  ".dishID=itemDish.dish JOIN calories ON calories.dish=dish" +
                  ".dishID JOIN item ON item.itemID=itemDish.item WHERE " +
                  "calories.person=?" +
                  " " +
                  "GROUP BY dish.dishID, calories.meal";
    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.setInt(1, getIDNumber(email));

      ResultSet rs = ps.executeQuery();
      ArrayList<String>id=new ArrayList<>();
      ArrayList<String>time=new ArrayList<>();
      ArrayList<String>name=new ArrayList<>();
      ArrayList<String>isVegan=new ArrayList<>();
      ArrayList<String>preset_calories=new ArrayList<>();
      ArrayList<ArrayList<String>>temp2=new ArrayList<>();
      if(rs.isBeforeFirst()) {
        while (rs.next()) {
          id.add(rs.getObject("dishid").toString());
          time.add(rs.getObject("meal").toString());
          name.add(rs.getObject("name").toString());
          isVegan.add(rs.getObject("vegan").toString());
          preset_calories.add(rs.getObject("preset_calories").toString());
        }

        for (int x=0; x<name.size();++x){
          ArrayList<String>dish=new ArrayList<>();
          dish.add(id.get(x));
          dish.add(time.get(x));
          dish.add(name.get(x));
          dish.add(isVegan.get(x));
          dish.add(preset_calories.get(x));
          temp2.add(dish);
        }
        return temp2;
      }
      else{
        ArrayList<ArrayList<String>>blank=new ArrayList<>();
        return blank;
      }
    } catch (SQLException throwables) {
      throwables.printStackTrace();
    }
    return null;
  }

  //should return the list of meals eaten only on the day specified
  public ArrayList<ArrayList<String>> getTodaysFoodEaten(String email,
                                                         String date) {

    String query ="SELECT dish.dishID,dish.name, meal, date AS eaten, CASE " +
                  "MIN" +
                  "(isVegan) WHEN" +
                  " 0 " +
                  "THEN 0 ELSE 1 END vegan, preset_calories FROM dish JOIN " +
                  "itemDish ON dish" +
                  ".dishID=itemDish.dish JOIN calories ON calories.dish=dish" +
                  ".dishID JOIN item ON item.itemID=itemDish.item WHERE " +
                  "calories.person=? AND eaten=?" +
                  " " +
                  "GROUP BY dish.dishID, calories.meal";
    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.setInt(1, getIDNumber(email));
      ps.setString(2,date);

      ResultSet rs = ps.executeQuery();
      ArrayList<String>id=new ArrayList<>();
      ArrayList<String>time=new ArrayList<>();
      ArrayList<String>name=new ArrayList<>();
      ArrayList<String>isVegan=new ArrayList<>();
      ArrayList<String>preset_calories=new ArrayList<>();
      ArrayList<ArrayList<String>>temp2=new ArrayList<>();
      if(rs.isBeforeFirst()) {
        while (rs.next()) {
          id.add(rs.getObject("dishid").toString());
          time.add(rs.getObject("meal").toString());
          name.add(rs.getObject("name").toString());
          isVegan.add(rs.getObject("vegan").toString());
          preset_calories.add(rs.getObject("preset_calories").toString());
        }

        for (int x=0; x<name.size();++x){
          ArrayList<String>dish=new ArrayList<>();
          dish.add(id.get(x));
          dish.add(time.get(x));
          dish.add(name.get(x));
          dish.add(isVegan.get(x));
          dish.add(preset_calories.get(x));
          temp2.add(dish);
        }
        return temp2;
      }
      else{
        ArrayList<ArrayList<String>>blank=new ArrayList<>();
        return blank;
      }
    } catch (SQLException throwables) {
      throwables.printStackTrace();
    }
    return null;
  }

  public boolean isAddDishToTable(String email, String mealTime, String dishID,
                                  String calories) {
    String query = "INSERT INTO calories(person,meal,dish,calories)\n" +
                   "VALUES(?,?,?,?)";

    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.setInt(1, getIDNumber(email));
      ps.setString(2, mealTime);
      ps.setInt(3, Integer.parseInt(dishID));
      ps.setInt(4, Integer.parseInt(calories));
      int x = ps.executeUpdate();
      return x > 0;
    } catch (NumberFormatException | SQLException e) {
      e.printStackTrace();
    }
    return false;
  }

  public ArrayList<ArrayList<Item>> getItemChooserList(String type) {
    String query = "SELECT *\n" +
                   "FROM item\n" +
                   "WHERE type=?";
    ArrayList<ArrayList<Item>>itemList=new ArrayList<>();
    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.setString(1, type);
      ResultSet rs=ps.executeQuery();
      while(rs.next()){
        ArrayList<Item>temp=new ArrayList<>();
        temp.add(new Item((Integer)rs.getObject("itemID"),
                          (String) rs.getObject("name"),
                          (String)rs.getObject("shop"),
                          (Integer)rs.getObject("isVegan"),
                          (String) rs.getObject("amount"),
                 (Integer)rs.getObject("calories"),
                 (String)rs.getObject("type")));

        itemList.add(temp);
      }
      return itemList;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  public ArrayList<ArrayList<Item>> getTempItems() {
    String query = "SELECT * FROM item join tempDish ON itemID=item";
    ArrayList<Item> temp = new ArrayList<>();
    try {
      Statement       s    = conn.createStatement();
      ResultSet       rs   = s.executeQuery(query);
      while (rs.next()) {
        temp.add(new Item((Integer) rs.getObject("itemID"),
                          (String) rs.getObject(
                              "name"),
                          (String) rs.getObject("shop"),
                          (Integer) rs.getObject(
                              "isVegan"),
                          (String) rs.getObject("amount"),
                          (Integer) rs.getObject(
                              "calories"),
                          (String) rs.getObject("type")));
      }
    } catch (SQLException throwables) {
      throwables.printStackTrace();
    }
    ArrayList<ArrayList<Item>>tempWrap=new ArrayList<>();
    tempWrap.add(temp);
    return tempWrap;
  }

  //this method simply adds the foreign key for items to a temp table for a
  // new dish
  public boolean isAddItemToDish(int id) {
    String create = "CREATE TABLE IF NOT EXISTS tempDish(\n" +
                    "item int NOT NULL UNIQUE,\n" +
                    "FOREIGN KEY (item) REFERENCES item(itemID)\n" +
                    ")";
    try {
      Statement s = conn.createStatement();
      s.executeUpdate(create);
    } catch (SQLException throwables) {
      throwables.printStackTrace();
    }

    try {
      String            query = "INSERT INTO tempDish VALUES (?)";
      PreparedStatement ps    = conn.prepareStatement(query);
      ps.setInt(1, id);
      int x=ps.executeUpdate();
      return x>0;
    } catch (SQLException e) {
      e.printStackTrace();
    }
return false;
  }

  //TODO not very sophisticated, could be improved?
  public ArrayList<ArrayList<Item>> getItemChooserListKeyword(String keyword) {
    String query = "SELECT *\n" +
                   "FROM item\n" +
                   "WHERE name LIKE (?)";
    ArrayList<ArrayList<Item>>itemList=new ArrayList<>();
    try {
      PreparedStatement ps = conn.prepareStatement(query);
      ps.setString(1, '%'+keyword+'%');
      ResultSet rs=ps.executeQuery();
      while(rs.next()){
        ArrayList<Item>temp=new ArrayList<>();
        temp.add(new Item((Integer)rs.getObject("itemID"),
                          (String) rs.getObject("name"),
                          (String)rs.getObject("shop"),
                          (Integer)rs.getObject("isVegan"),
                          (String) rs.getObject("amount"),
                          (Integer)rs.getObject("calories"),
                          (String)rs.getObject("type")));

        itemList.add(temp);
      }
      return itemList;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  public void dropTables() {

    String[] commands = {
        "PRAGMA foreign_keys=off;",
        "drop table if exists person;",
        "drop table if exists item;",
        "drop table if exists dish;",
        "drop table if exists itemdish;",
        "drop table if exists calories;",
        "drop table if exists weight;",
        "drop table if exists tempDish;"};

    for (String query : commands) {

      try (PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.executeUpdate();
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
  }

  public void resetDatabase(String file, String file2) {

    dropTables();

    ArrayList<String> defs = loadSQL(file);

    ArrayList<String> data =  loadSQL(file2);

    executeSQLUpdates(defs);
    executeSQLUpdates(data);
  }

  private void executeSQLUpdates(ArrayList<String> commands) {

    for (String query: commands) {

      try (PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.executeUpdate();
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
  }

  private ArrayList<String> loadSQL(String sqlfile) {

    /*
     * This method is to be used only by the resetDatabase() code.
     * Do not use it yourself to load your own SQL.
     */

    ArrayList<String> commands = new ArrayList<String>();

    try {
      BufferedReader reader = new BufferedReader(new FileReader(sqlfile + ".sql"));

      String command = "";

      String line = "";

      while ((line = reader.readLine())!= null) {

        if (line.contains(";")) {
          command += line;
          command = command.trim();
          commands.add(command);
          command = "";
        }

        else {
          line = line.trim();
          command += line + " ";
        }
      }

      reader.close();

    } catch (IOException e) {
      e.printStackTrace();
    }

    return commands;

  }
}
