package tests;

import org.junit.jupiter.api.*;
import server_side.Database;
import server_side.Item;

import java.sql.Date;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_METHOD)
class DatabaseTest {

  static  String   goodEmail = "veron451@yahoo.co.uk";
  static  String   badEmail = "fucker@lol.com";
  static  String   goodPass  = "sprout";
  private Database db        = null;
  private     ArrayList<ArrayList<String>> blank     = new ArrayList<>();
  private     ArrayList<ArrayList<Item>>   blankItem = new ArrayList<>();


  @BeforeEach
  void setUp() {
    db = new Database();
    db.openDatabase();
  }

  @Test
  void signInTestGood() {
    assertEquals(true, db.signIn(goodEmail, goodPass));
  }

  @Test
  void signInTestBad() {
    assertEquals(false, db.signIn(goodPass, "al"));
  }

  @Test
  @DisplayName("checks to see if the userID get method works")
  void checkID() {
    db.getIDNumber(goodEmail);
    assertEquals(1, db.getIDNumber(goodEmail));
  }

  @Test
  @DisplayName("checks to see if the weight booleans are correct")
  void checkWeight() {
    boolean a = db.addWeight(1, "150");

    assertTrue(a);
  }

//  @Test
//  void checkWeightThrow() {
//    Assertions.assertThrows(Exception.class, () -> db.addWeight(1, "0"));
//  }

  @Test
  @DisplayName("checks the get calorie goal method")
  void checkCalorieGoal() {
    assertEquals(2000, db.getCalories(1));
    assertNotEquals(2000, db.getCalories(2));
    assertEquals(0, db.getCalories(2));
  }

  @Test
  @DisplayName("checks the get meals method, should return every meal they've" +
               " eaten")
  void checkGetMeals() {
    ArrayList<ArrayList<String>> tester     = new ArrayList<>();
    ArrayList<ArrayList<String>> goodTester = new ArrayList<>();
    ArrayList<String>            goodData   = new ArrayList<>();
    goodData.add("1");
    goodData.add("breakfast");
    goodData.add("ham sandwich");
    goodData.add("1");
    goodData.add("226");

    ArrayList<String> temp = new ArrayList<>();
    goodTester.add(goodData);

    tester.add(temp);

    assertEquals(goodTester, db.getMealList(goodEmail));
    assertNotEquals(tester, db.getMealList(goodEmail));
    assertEquals(blank, db.getMealList("greavsie"));
  }

  @Test
  void checkMealsNotNull() {
    ArrayList<String> test = new ArrayList<>();
    test.add(db.getMealList(goodEmail).get(0).get(0));
    for (String s : test) {
      System.out.println(s);
    }
  }

  @Test
  @DisplayName("checks to see if the table update by double clicking works " +
               "and sends to calories table")
  void checkIsAddToTable() {
    assertTrue(db.isAddDishToTable(goodEmail, "dinner", "1", "300"));
//    assertFalse(db.isAddDishToTable("greavsie", "tea", "5", "450"));
  }

@Test
@DisplayName("checks to see if the method returns the food eaten on the date " +
             "specified")
void checkGetTodaysFood() {
  assertNotEquals(blank, db.getTodaysFoodEaten(goodEmail,"2021-08-03"));
  assertNotEquals(blank, db.getTodaysFoodEaten(goodEmail, LocalDate.now().toString()));
  assertEquals(blank, db.getTodaysFoodEaten(goodEmail,"2021-08-02"));
}

  @Test
  @DisplayName("checks to see if the itemChooser method returns the correct " +
               "list of Items")
  void checkGetItemChooser() {
    assertNotEquals(blankItem, db.getItemChooserList("bread"));
    assertNotEquals(blankItem, db.getItemChooserList("\"meat\""));
    assertEquals(blankItem, db.getItemChooserList("rich evans"));
  }

  @Test
  @DisplayName("checks the ItemChooser by keyword")
  void checkItemChooserKeyword(){
    assertNotEquals(blankItem, db.getItemChooserListKeyword("ham"));
    assertNotEquals(blankItem, db.getItemChooserListKeyword("ha"));
    assertNotEquals(blankItem, db.getItemChooserListKeyword("am"));
    assertNotEquals(blankItem, db.getItemChooserListKeyword("brown brea"));
    assertEquals(blankItem,db.getItemChooserListKeyword("rich evans"));
  }

  @Test
  @DisplayName("checks the temp table add and creation")
  void checkTempAdd(){
//    assertTrue(db.isAddItemToDish(1));
  }

  @Test
  @DisplayName("check the item list for the temp table")
  void checkTempList(){
    assertNotEquals(blankItem,db.getTempItems());
  }

  @AfterEach
  void reset() {
    if (db.getConnection() != null) {
      db.closeDatabase();
    }
    db.openDatabase();
    db.resetDatabase("tabledef", "tabledebugdata");
    db.closeDatabase();
  }

}