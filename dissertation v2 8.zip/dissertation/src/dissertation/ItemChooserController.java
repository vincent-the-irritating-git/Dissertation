package dissertation;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import server_side.Item;
import server_side.Message;
import server_side.Protocol;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class ItemChooserController implements Initializable {

  /////////////////////////
  @FXML
  ImageView item1Pic;
  @FXML
  Label     item1isVegan;
  @FXML
  Label     item1Shop;
  @FXML
  Label     item1Name;

  /////////////////////////
  @FXML
  ImageView item2Pic;
  @FXML
  Label     item2isVegan;
  @FXML
  Label     item2Shop;
  @FXML
  Label     item2Name;
  /////////////////////////
  @FXML
  ImageView item3Pic;
  @FXML
  Label     item3isVegan;
  @FXML
  Label     item3Shop;
  @FXML
  Label     item3Name;
  /////////////////////////
  @FXML
  ImageView item4Pic;
  @FXML
  Label     item4isVegan;
  @FXML
  Label     item4Shop;
  @FXML
  Label     item4Name;
  /////////////////////////
  @FXML
  ImageView item5Pic;
  @FXML
  Label     item5isVegan;
  @FXML
  Label     item5Shop;
  @FXML
  Label     item5Name;
  /////////////////////////
  @FXML
  ImageView item6Pic;
  @FXML
  Label     item6isVegan;
  @FXML
  Label     item6Shop;
  @FXML
  Label     item6Name;
  /////////////////////////
  @FXML
  ImageView item7Pic;
  @FXML
  Label     item7isVegan;
  @FXML
  Label     item7Shop;
  @FXML
  Label     item7Name;
  /////////////////////////
  @FXML
  ImageView item8Pic;
  @FXML
  Label     item8isVegan;
  @FXML
  Label     item8Shop;
  @FXML
  Label     item8Name;
  /////////////////////////
  @FXML
  ImageView item9Pic;
  @FXML
  Label     item9isVegan;
  @FXML
  Label     item9Shop;
  @FXML
  Label     item9Name;
  /////////////////////////
  @FXML
  ImageView item10Pic;
  @FXML
  Label     item10isVegan;
  @FXML
  Label     item10Shop;
  @FXML
  Label     item10Name;
  /////////////////////////
  @FXML
  ImageView item11Pic;
  @FXML
  Label     item11isVegan;
  @FXML
  Label     item11Shop;
  @FXML
  Label     item11Name;
  /////////////////////////
  @FXML
  ImageView item12Pic;
  @FXML
  Label     item12isVegan;
  @FXML
  Label     item12Shop;
  @FXML
  Label     item12Name;
  /////////////////////////
  @FXML
  ImageView item13Pic;
  @FXML
  Label     item13isVegan;
  @FXML
  Label     item13Shop;
  @FXML
  Label     item13Name;
  /////////////////////////
  @FXML
  ImageView item14Pic;
  @FXML
  Label     item14isVegan;
  @FXML
  Label     item14Shop;
  @FXML
  Label     item14Name;
  /////////////////////////
  @FXML
  ImageView item15Pic;
  @FXML
  Label     item15isVegan;
  @FXML
  Label     item15Shop;
  @FXML
  Label     item15Name;
  ////////////////////////
  @FXML
  private Label item1ID;
  @FXML
  private Label item2ID;
  @FXML
  private Label item3ID;
  @FXML
  private Label item4ID;
  @FXML
  private Label item5ID;
  @FXML
  private Label item6ID;
  @FXML
  private Label item7ID;
  @FXML
  private Label item8ID;
  @FXML
  private Label item9ID;
  @FXML
  private Label item10ID;
  @FXML
  private Label item11ID;
  @FXML
  private Label item12ID;
  @FXML
  private Label item13ID;
  @FXML
  private Label item14ID;
  @FXML
  private Label item15ID;
  ///////////////////////////

  private ArrayList<ArrayList<Item>> tableList;
  private Protocol p=new Protocol();

  //constructor, takes the list of Items in getData format
  public ItemChooserController(ArrayList<ArrayList<Item>> tableList) {
    this.tableList = tableList;
  }

  //gives us the data to set up the table
  private void setUpTable() {
    //TODO should set 'V' not 0/1
    ImageView[]                picArray = {
        item1Pic, item2Pic, item3Pic, item4Pic, item5Pic,
        item6Pic, item7Pic, item8Pic, item9Pic, item10Pic
        , item11Pic, item12Pic, item13Pic, item14Pic, item15Pic
    };
    Label[]name={item1Name,item2Name,item3Name,item4Name,item5Name,item6Name,
                 item7Name,item8Name,item9Name,item10Name,item11Name,
                 item12Name,item13Name,item14Name,item15Name};
    Label[]vegan={item1isVegan,item2isVegan,item3isVegan,item4isVegan,
                  item5isVegan,item6isVegan,item7isVegan,item8isVegan,
                  item9isVegan,item10isVegan,item11isVegan,item12isVegan,
                  item13isVegan,item14isVegan,item15isVegan};
    Label[]shop={item1Shop,item2Shop,item3Shop,item4Shop,item5Shop,item6Shop,
        item7Shop,item8Shop,item9Shop,item10Shop,item11Shop,item12Shop,
        item13Shop,item14Shop,item15Shop};
    Label[]ID={item1ID,item2ID,item3ID,item4ID,item5ID,item6ID,item7ID,
               item8ID,item9ID,item10ID,item11ID,item12ID,item13ID,item14ID,
               item15ID};

    try {
      for (int x = 0; x < 15; ++x) {
        picArray[x].setImage((new Image("dissertation/fxml/pictures/" +
                                        tableList.get(x).get(0).getItemID() +
                                        ".png")));
        name[x].setText(tableList.get(x).get(0).getName());
        shop[x].setText(tableList.get(x).get(0).getShop());
        vegan[x].setText(veganBoolean(tableList.get(x).get(0).getIsVegan()));
        ID[x].setText(String.valueOf(tableList.get(x).get(0).getItemID()));
      }
    }catch (NullPointerException|IndexOutOfBoundsException e) {
      e.printStackTrace();
    }

  }

  //converts the boolean to a string character
  public String veganBoolean(int x){
    if (x==0){
      return "Ve";
    }
    else
      return "V";
  }

  //adds the food to the recipe builder
  public void addItemToCreateDish(String id){
    /*adds the item to the table in addDish. also adds to relation
    'tempDish', creates if not extant already.
     */
    Message message=new Message("add-item-to-new-dish");
    p.protocolToUse(message);
  }

  @Override
  public void initialize(URL url, ResourceBundle resourceBundle) {
    setUpTable();
  }

}
