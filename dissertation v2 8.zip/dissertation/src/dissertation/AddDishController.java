package dissertation;

import javafx.application.Application;
import javafx.beans.InvalidationListener;
import javafx.beans.binding.NumberBinding;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableDoubleValue;
import javafx.beans.value.ObservableNumberValue;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Callback;
import misc.Quantities;
import server_side.Dish;
import server_side.Item;
import server_side.Message;
import server_side.Protocol;

import java.io.IOException;
import java.net.URL;
import java.text.NumberFormat;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.function.DoublePredicate;
import java.util.function.Predicate;

public class AddDishController extends Application implements Initializable {

  @FXML
  private Button                     goBack;
  @FXML
  private Pane                       pane;
  @FXML
  private TextField                  searchBar;
  @FXML
  private TableView<Dish>            results;
  @FXML
  private TableColumn<Dish, String>  name     = new TableColumn<>();
  @FXML
  private TableColumn<Dish, Boolean> isVegan  = new TableColumn<>();
  @FXML
  private TableColumn<Dish, String>  calories = new TableColumn<>();
  @FXML
  private Label DEBUG=new Label();

  ////////////////////////////NEW DISH////////////////////////////////
  //==================================================================
  private ObservableList<Item>                             itemDishList =
      FXCollections.observableArrayList();
  @FXML
  private TableView<Item>                                  newDishTable;
  @FXML
  private TableColumn<Item, String>                        itemName     =
      new TableColumn<>();
  //TODO get this working as a drop down box to do the quantities
  @FXML
  TableColumn<Item, String>itemAmount=new TableColumn<>();
  //TODO get this bound to the item's calorie value times amount
  @FXML
  private TableColumn<Item, Number>                       itemCalories =
      new TableColumn<>();
  @FXML
  private TableColumn<Item, String>                        itemVegan    =
      new TableColumn<>();
  //===================================================================

  private static String   mealTime;
  private final  String   DEBUGEMAIL = "veron451@yahoo.co.uk";
  private        String   space      = " ";
  private        Protocol p          = new Protocol();

  private FilteredList<Dish> filteredData =
      new FilteredList<>(FXCollections.observableList(prepareListForFiltering(
          DEBUGEMAIL)));

  private Predicate<Dish> createPredicate(String searchText) {
    return dish -> {
      if (searchText == null || searchText.isEmpty()) return true;
      return isSearchFindsDish(dish.getName(), searchText);
    };
  }

  public AddDishController() throws IOException {}

  public String getMealTime() {
    return mealTime;
  }

  //TODO swap this for a loader
  public void setMealTime(String mealTime) {
    AddDishController.mealTime = mealTime;
  }

  //=======================================================================================================================

  @Override
  public void initialize(URL url, ResourceBundle resourceBundle) {

    ///////////////////////////////NEW DISH////////////////////////////////
    //===================================================================//
    itemDishList.addAll(getTempItems());
    try {
      newDishTable.setItems(itemDishList);
    } catch (NullPointerException e) {
      e.printStackTrace();
    }

    itemName.setCellValueFactory(new PropertyValueFactory<>("Name"));
    itemCalories.setCellValueFactory(new PropertyValueFactory<>(
        "caloriesBound"));
    itemAmount.setCellFactory(ComboBoxTableCell->{



      //set up the combobox
      ComboBox<String> combo = new ComboBox<>();
      //load the combobox content
      Quantities q=new Quantities() {
        @Override
        public ArrayList<String> addValuesString(String container) {
          return super.addValuesString(container);
        }
        @Override
        public quantity getQuantityFromString(String quantity) {
          return super.getQuantityFromString(quantity);
        }
      };
      //set up the tablecell
      TableCell<Item, String> cell =
          new TableCell<>() {
            @Override
            //this actually *displays* the cell on screen
            protected void updateItem(String string, boolean empty) {
              try {
                  int row = this.getTableRow().getIndex();
                  Item item =
                      this.getTableRow().getTableView().getItems().get(row);

                  System.out.println(item.getAmount());
                  ObservableList<String>list=
                  FXCollections.observableArrayList(q.addValuesString((item.getAmount())));
                  combo.setItems(list);

              }catch (IndexOutOfBoundsException e){e.printStackTrace();}
//              Item item = getTableView().getItems().get(getIndex());
              super.updateItem(string, empty);
              if (empty) {
                setGraphic(null);
              } else {
                combo.setValue(string);
                setGraphic(combo);
              }
            }
          };

      //placeholder for combobox
      Label loader=new Label("Select an item");
      combo.setPlaceholder(loader);

      combo.valueProperty().addListener((observableValue, o, n) -> {
        System.out.println(n);
        //this is the current tablerow
        int row = cell.getTableRow().getIndex();
        //this is the properties for the current row
        ObservableList<Item> list =
            cell.getTableRow().tableViewProperty().get().getItems();
        //this is the current item
        Item                   item  =list.get(row);
        //now we convert the string to enum
        double percent=q.getQuantityFromString(combo.getValue()).getPercent();
        //... this actually does what we wanted and set it
        item.setPerCent(percent);
        double v=item.getPerCent()*item.getCalories();
        System.out.println("value should be "+v);
        item.setCaloriesBound(item.getPerCent()*item.getCalories());
      });

      return cell;
    });
    itemVegan.setCellValueFactory(new PropertyValueFactory<>("veganString"));

    //////////////////////////////SEARCH DISH//////////////////////////////
    //===================================================================//
    /*DEBUG, NEEDS TO BE GETEMAIL*/
    //setting up the search Dish table
    name.setCellValueFactory(new PropertyValueFactory<>("name"));
    isVegan.setCellValueFactory(new PropertyValueFactory<>("isVegan"));
    calories.setCellValueFactory(new PropertyValueFactory<>("calories"));
    //setting the filtered list up and making the search bar listener
    results.setItems(filteredData);
    searchBar.textProperty().addListener((observable, oldValue, newValue) ->
                                             filteredData.setPredicate(
                                                 createPredicate(newValue))
                                        );
    //making the table be double clickable
    results.setRowFactory(tv -> {
      TableRow<Dish> row = new TableRow<>();
      row.setOnMouseClicked(event -> {
        if (event.getClickCount() == 2 && (!row.isEmpty())) {
          Dish rowData = row.getItem();
          addDishToMeal(mealTime, rowData);
          openNewWindow("fxml//body.fxml");
        }
      });
      return row;
    });


    //bind method to goBack button
    goBack.setOnAction(EventHandler -> openNewWindow("fxml//body.fxml"));
  }

  @Override
  public void start(Stage stage) throws Exception {

  }
  //========================================================================================================================//

  //this method tests whether or not the words in the field match
  //TODO make private after testing
  public static boolean isSearchFindsDish(String dish, String searchText) {
    return dish.toLowerCase().contains(searchText.toLowerCase());
  }

  //this returns our the data got by getMealList()
  //in dish format
  //TODO make private after testing
  public List<Dish> prepareListForFiltering(String email) {
    ArrayList<ArrayList<String>> listOfLists = getListOfMeals(email);
    List<Dish>                   dish        = new ArrayList<>();
    ArrayList<Integer>           IDs         = new ArrayList<>();

    for (ArrayList<String> listOfList : listOfLists) {
      Dish singleDish = new Dish(Integer.parseInt(listOfList.get(0)),
                                 listOfList.get(1), listOfList.get(2),
                                 Integer.parseInt(listOfList.get(3)),
                                 listOfList.get(4));
      //should not return duplicate meals here
      if (!IDs.contains(singleDish.getID())) {
        dish.add(singleDish);
        IDs.add(singleDish.getID());
      }

    }
    return dish;
  }

  //this gets the list to filter
  //TODO this is taking the email manually at the moment. Bug, won't add
  // duplicate meals to the list with different meal times
  public ArrayList<ArrayList<String>> getListOfMeals(String email) {
    ArrayList<ArrayList<String>> nullArray = new ArrayList<>();
    Message message =
        new Message("meals" + space + email);
    p.protocolToUse(message);
    Message messageIn = p.getM();
    if (messageIn.getMessage().equals("returned-list")) {
      return messageIn.getData();
    } else {
      return nullArray;
    }
  }

  public void createNewDish() {
    openNewWindow("fxml//selectItem.fxml");
  }

  public void addDishToMeal(String name, Dish rowData) {
    Message message =
        new Message("add-dish-to-table" +
                    space +
                    Main.getEmail() +
                    space +
                    name +
                    space +
                    rowData.getID() +
                    space +
                    rowData.getCalories());
    System.out.println(message.getMessage());
    p.protocolToUse(message);
    Message messageIn = p.getM();
    System.out.println(messageIn.getMessage());
  }

  public void openNewWindow(String window) {
    //to hide
    Stage stage;
    stage = (Stage) pane.getScene().getWindow();
    stage.hide();
    FXMLLoader loader = new FXMLLoader();
    try {
      Pane root =
          loader.load(getClass().getResource(window).openStream());
      Scene scene = new Scene(root);
//      scene.getStylesheets()
//           .add(getClass().getResource("application.css").toExternalForm());
      stage.setScene(scene);
    } catch (Exception e) {
      e.printStackTrace();
    }
    stage.show();
  }

  public ArrayList<Item> getTempItems() {
    Message message = new Message("get-temp-items");
    p.protocolToUse(message);
    return p.getM().getDataItem().get(0);
  }

}
