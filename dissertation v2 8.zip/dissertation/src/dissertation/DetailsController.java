package dissertation;

import javafx.event.ActionEvent;

public class DetailsController {
  public void changeName(ActionEvent event) {
  }

  public void changeEmail(ActionEvent event) {
  }

  public void changePassword(ActionEvent event) {
  }

  public void changeHeight(ActionEvent event) {
  }

  public void changeWeight(ActionEvent event) {
  }
}
