package dissertation;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import server_side.Item;
import server_side.Message;
import server_side.Protocol;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class SelectItemController implements Initializable {

  @FXML
  private Pane                       masterPane;

  @FXML
  private Button search;

  @FXML
  private GridPane choiceTable;
  @FXML
  private GridPane bakery;
  @FXML
  private GridPane freshFood;
  @FXML
  private GridPane drinks;
  @FXML
  private GridPane foodCupboard;
  @FXML
  private GridPane frozenReady;
  @FXML
  private GridPane chilledFood;

  @FXML
  private GridPane pane1;
  @FXML
  private GridPane pane2;
  @FXML
  private GridPane pane3;
  @FXML
  private GridPane pane4;
  @FXML
  private GridPane pane5;
  @FXML
  private GridPane pane6;

  @FXML
  private Label choice1;
  @FXML
  private Label choice2;
  @FXML
  private Label choice3;
  @FXML
  private Label choice4;
  @FXML
  private Label choice5;
  @FXML
  private Label choice6;

  @FXML
  private TextField       searchBar;

  private Protocol                            p        =new Protocol();

  @Override
  public void initialize(URL url, ResourceBundle resourceBundle) {
    search.setOnMouseClicked(MouseEvent->{
      search(searchBar.getText());
    });

    //if we leave the choiceTable, the column collapses
    choiceTable.setOnMouseExited(mouseEvent -> {
      defaultView();
    });
    /*////////////////////////////////////////////////////////////////////////////////////*/
    bakery.setOnMouseEntered(new EventHandler<MouseEvent>() {
      @Override
      public void handle(MouseEvent mouseEvent) {
        showChoices();
        choice1.setText("Bread");
        choice1.setVisible(true);
        choice2.setText("Cakes");
        choice2.setVisible(true);
      }
    });
    freshFood.setOnMouseEntered(mouseEvent -> {
      showChoices();
      choice1.setText("Fruit 'n' Veg");
      choice1.setVisible(true);
      choice2.setText("\"Meat\"");
      choice2.setVisible(true);
    });
    drinks.setOnMouseEntered(MouseEvent->{
      showChoices();
      choice1.setText("Non-Alcoholic");
      choice1.setVisible(true);
      choice2.setText("Alcoholic");
      choice2.setVisible(true);
    });
    foodCupboard.setOnMouseEntered(MouseEvent->{
      showChoices();
      choice1.setText("Cereal");
      choice1.setVisible(true);
      choice2.setText("Chocolate, Crisps and Biscuits");
      choice2.setVisible(true);
      choice3.setText("Sauces, Oil and Dressings");
      choice3.setVisible(true);
      choice4.setText("Pasta");
      choice4.setVisible(true);
      choice5.setText("Nuts");
      choice5.setVisible(true);
      choice6.setText("Seasoning");
      choice6.setVisible(true);
    });
    frozenReady.setOnMouseEntered(MouseEvent->{
      showChoices();
      choice1.setText("Frozen Food");
      choice1.setVisible(true);
      choice2.setText("Ready Meals");
      choice2.setVisible(true);
    });
    chilledFood.setOnMouseEntered(MouseEvent->{
      showChoices();
      choice1.setText("Cheese");
      choice1.setVisible(true);
      choice2.setText("Milk and Eggs");
      choice2.setVisible(true);
      choice3.setText("Spread");
      choice3.setVisible(true);
    });
    /*////////////////////////////////////////////////////////////////////////////////////*/
    //if we press the panes, we go to the item selector screen
    pane1.setOnMouseClicked(MouseEvent-> {
      loadItemChooser(choice1.getText());
    });
    pane2.setOnMouseClicked(MouseEvent-> {
      loadItemChooser(choice2.getText());
    });
    pane3.setOnMouseClicked(MouseEvent-> {
      loadItemChooser(choice3.getText());
    });
    pane4.setOnMouseClicked(MouseEvent-> {
      loadItemChooser(choice4.getText());
    });
    pane5.setOnMouseClicked(MouseEvent-> {
      loadItemChooser(choice5.getText());
    });
    pane6.setOnMouseClicked(MouseEvent-> {
      loadItemChooser(choice6.getText());
    });
  }

  //resets the table clear of columns
  private void defaultView() {
    pane1.setVisible(false);
    pane2.setVisible(false);
    pane3.setVisible(false);
    pane4.setVisible(false);
    pane5.setVisible(false);
    pane6.setVisible(false);
  }

  //shows the columns of the choices
  public void showChoices(){
    choice1.setText("");
    pane1.setVisible(true);
    pane1.setGridLinesVisible(true);
    choice2.setText("");
    pane2.setVisible(true);
    pane2.setGridLinesVisible(true);
    choice3.setText("");
    pane3.setVisible(true);
    pane3.setGridLinesVisible(true);
    choice4.setText("");
    pane4.setVisible(true);
    pane4.setGridLinesVisible(true);
    choice5.setText("");
    pane5.setVisible(true);
    pane5.setGridLinesVisible(true);
    choice6.setText("");
    pane6.setVisible(true);
    pane6.setGridLinesVisible(true);
  }

  //sets the type in ItemChooser to be the type extracted from the box
  public void loadItemChooser(String type){
    if (type.isEmpty()){
      return;
    }
    Message message = new Message("itemChooser-table" + " " + type);
    p.protocolToUse(message);
    Message messageIn = p.getM();
    URL location =
        getClass().getResource("fxml//ItemChooser.fxml");
    FXMLLoader            loader = new FXMLLoader(location);
    ItemChooserController icc    = new ItemChooserController(messageIn.getDataItem());
    loader.setController(icc);
    try {
      Parent root = loader.load();
      Stage  stage;
      stage = (Stage) masterPane.getScene().getWindow();
      stage.hide();
      Main.openNewWindow(root);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  //opens up the icc page with results filtered by our keyword
  public void search(String keyword){
    if (keyword.isBlank()){
      return;
    }
    Message message=new Message("itemChooser-table-keyword"+" "+keyword);
    p.protocolToUse(message);
    Message messageIn=p.getM();
    URL location =
        getClass().getResource("fxml//ItemChooser.fxml");
    FXMLLoader            loader = new FXMLLoader(location);
    ItemChooserController icc    = new ItemChooserController(messageIn.getDataItem());
    loader.setController(icc);

    try {
      Parent root = loader.load();
      Stage  stage;
      stage = (Stage) masterPane.getScene().getWindow();
      stage.hide();
      Main.openNewWindow(root);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

}
