package tests;

import org.junit.jupiter.api.*;
import server_side.Database;
import server_side.Item;
import server_side.Message;
import server_side.Protocol;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_METHOD)
class ItemChooserControllerTest {

  private Database db = null;
  private Protocol                   p        =null;
  private ArrayList<ArrayList<Item>> itemList =new ArrayList<>();

  @BeforeEach
  void setUp() {
    db = new Database();
    db.openDatabase();
    p=new Protocol();
  }

  @Test
  @DisplayName("check to see if the itemList initialises on scene change")
  void setUpTable(){
    String type="bread";
    Message message =new Message("itemChooser-table" + " " + type);
    p.protocolToUse(message);
    itemList=p.getM().getDataItem();
    assertEquals(itemList,p.getM().getDataItem());
    assertEquals("aldi",p.getM().getDataItem().get(0).get(0).getShop());
  }

  @AfterEach
  void reset() {
//    itemList.clear();
    if (db.getConnection() != null) {
      db.closeDatabase();
    }
    db.openDatabase();
    db.resetDatabase("tabledef", "tabledebugdata");
    db.closeDatabase();
  }
}