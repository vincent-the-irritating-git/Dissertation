package dissertation;

public class LogBookController {
}
